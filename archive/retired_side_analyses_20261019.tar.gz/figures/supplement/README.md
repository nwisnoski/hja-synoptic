# Supporting figures

The four selected figures are in [../manuscript](../manuscript). These folders
retain their individual panels, supporting analyses, and required diagnostics.
Scripts write directly to these folders; retired plots are recorded in
[the cleanup manifest](../../archive/cleanup_20261014.csv).

| Folder | Content | Producer in `analysis/` |
| --- | --- | --- |
| [habitat_diversity](habitat_diversity) | Sampling map, diversity, ordinations, soil sharing, same-site metrics | `02_habitat_diversity.R` |
| [first_detection](first_detection) | First-detection inventory, Figure 2 iCAMP panels, supplementary paired soil sharing and taxonomic resolution | `03_first_detection.R` |
| [sediment_comparison](sediment_comparison) | Matched-site dispersion panels and molecular classes | `04_sediment_convergence.R` |
| [networks](networks) | Association groups, null diagnostics, stability, distribution maps | `05_network_localization.R`; supporting 07–09 |
| [icamp](icamp/README.md) | Reviewed-pool overviews and sediment-only sensitivity | `supporting/icamp/` |
| [molecular](molecular) | Full-site molecular composition, detection QC, dispersion sensitivities | Supporting 01–02 and 05 |
| [chemistry](chemistry) | Water optics and integrated chemistry | Supporting 03–04 |
| [sediment_conditions](sediment_conditions) | Coverage and conditional associations with sediment properties | Supporting 10 |
| [sediment_diversity](sediment_diversity) | Sediment-only microbial ordination and diversity | Supporting 11 |
| [transformations](transformations) | Putative mass-difference profiles, ranked labels, assignment checks, and detection diagnostics | Supporting 12 and 14 |
| [transformation_context](transformation_context) | River-position profiles and the mapped group's chemical neighborhood | Supporting 13 |
| [enzyme_transformations](enzyme_transformations) | Targeted potential-enzyme associations with compatible formula differences | Supporting 15 |
| [transformation_gradients](transformation_gradients) | Observed and detection-adjusted PCA, loadings, scree, and descriptive environmental correlations | Supporting 16 |
| [transformation_detection_review](transformation_detection_review) | Paired model comparisons without detection conditioning and observed PCA enzyme gradients | Supporting 17 |

Supporting figures include exploratory analyses; their presence does not select
them for the manuscript. Current transformation interpretation centers on the
bulk catalogue and assignment summaries in `transformations/`. Enzyme comparisons
are retained as exploratory results and are excluded from proposed main-text
claims. See [the interpretation note](../../analysis/TRANSFORMATION_CONTEXT.md).
Definitions and interpretation limits are in
[METHODS.md](../../analysis/METHODS.md).
