# Unsupervised gradients in transformation profiles, with a detection adjustment.
# PC scores describe formula-difference inventories, not metabolic rates.

library(here)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)

# 1. Settings and plot definitions ---------------------------------------------
results_dir <- here("results", "fticr_2016", "transformation_gradients")
figures_dir <- here("figures", "supplement", "transformation_gradients")
n_saved_axes <- 3L
n_scree_axes <- 10L
loadings_per_direction <- 6L
view_labels <- c(observed = "Observed profiles", detection_adjusted = "Detection-adjusted profiles")
group_colors <- c(Headwater = "#009E73", Intermediate = "#E69F00", Mainstem = "#0072B2")
gradient_design <- tribble(
  ~variable, ~label,
  "log_detection", "Detection count",
  "log_area", "Drainage area",
  "log_organic", "Organic content",
  "glu", "GLU",
  "lap", "LAP",
  "nag", "NAG",
  "ap", "AP"
)
plot_theme <- theme_bw(base_size = 11) +
  theme(panel.grid = element_blank(), strip.background = element_blank(),
    legend.position = "bottom")

# 2. Read the completed profiles and aligned sediment measurements --------------
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)
input_paths <- c(
  here("results", "fticr_2016", "transformations", "transformation_profiles.csv"),
  here("results", "fticr_2016", "transformations", "site_summary.csv"),
  here("data", "derived", "analysis_inputs", "sediment_multiblock", "sediment_44_enzyme_activity.csv"),
  here("results", "fticr_2016", "transformations", "profile_pca_scores.csv"),
  here("results", "fticr_2016", "transformations", "profile_pca_variance.csv"),
  here("results", "fticr_2016", "transformations", "interpretable_motif_summary.csv")
)
input_md5 <- unname(tools::md5sum(input_paths))
stopifnot(!anyNA(input_md5))
profiles <- read_csv(input_paths[1], show_col_types = FALSE)
site <- read_csv(input_paths[2], col_types = cols(site_code = col_character()))
enzymes <- read_csv(input_paths[3], col_types = cols(site_code = col_character()))
previous_scores <- read_csv(input_paths[4], col_types = cols(site_code = col_character()))
previous_variance <- read_csv(input_paths[5], show_col_types = FALSE)
motif_names <- read_csv(input_paths[6], show_col_types = FALSE)
stopifnot(!anyDuplicated(site$site_code), !anyDuplicated(enzymes$site_code),
  setequal(site$site_code, enzymes$site_code))
site <- site %>% left_join(enzymes, by = "site_code") %>%
  mutate(network_group = factor(case_when(site_stream_order <= 2 ~ "Headwater",
    site_stream_order <= 4 ~ "Intermediate", site_stream_order == 5 ~ "Mainstem"),
    levels = names(group_colors)),
    log_detection = log10(detected_features),
    log_area = log10(site_drainage_area_ha),
    log_organic = log10(sediment_organic_content_percent))
enzyme_variables <- c(glu = "sediment_glu_umol_g_hr", lap = "sediment_lap_umol_g_hr",
  nag = "sediment_nag_umol_g_hr", ap = "sediment_ap_umol_g_hr")
for (variable in names(enzyme_variables)) {
  x <- site[[enzyme_variables[variable]]]
  stopifnot(all(x[is.finite(x)] >= 0))
  site[[variable]] <- asinh(x / median(x[is.finite(x) & x > 0]))
}
counts <- t(as.matrix(profiles[, site$site_code]))
colnames(counts) <- as.character(profiles$database_row)
stopifnot(nrow(counts) == 44, all(rowSums(counts) == site$matched_peak_pairs))
hellinger <- sqrt(counts / rowSums(counts))

# 3. Fit ordinary PCA and PCA after removing the detection-associated component -
# Center columns without scaling to unit variance: rare labels are not amplified.
# Detection adjustment removes the fitted intercept, log count, and its square
# from every Hellinger coordinate. Negative residuals are valid PCA inputs.
# This adjustment can remove biological covariation as well as detection effects.
nuisance <- model.matrix(~ log_detection + I(log_detection^2), data = site)
residual_profiles <- qr.resid(qr(nuisance), hellinger)
observed_variance <- sum(scale(hellinger, center = TRUE, scale = FALSE)^2)
views <- list(observed = hellinger, detection_adjusted = residual_profiles)
score_rows <- list()
variance_rows <- list()
loading_rows <- list()
validation_rows <- list()
for (view in names(views)) {
  response <- views[[view]]
  pca <- prcomp(response, center = TRUE, scale. = FALSE)
  # Retain the original observed orientation; orient each residual axis by its
  # largest absolute loading. Axis signs otherwise have no biological meaning.
  if (view == "detection_adjusted") {
    for (axis in seq_len(n_saved_axes)) {
      largest <- which.max(abs(pca$rotation[, axis]))
      if (pca$rotation[largest, axis] < 0) {
        pca$rotation[, axis] <- -pca$rotation[, axis]
        pca$x[, axis] <- -pca$x[, axis]
      }
    }
  }
  view_variance <- sum(scale(response, center = TRUE, scale = FALSE)^2)
  percent <- 100 * pca$sdev^2 / sum(pca$sdev^2)
  variance_rows[[view]] <- tibble(view, axis = seq_along(percent),
    percent_within_view = percent,
    percent_of_observed_variance = percent * view_variance / observed_variance,
    cumulative_percent_within_view = cumsum(percent),
    retained_observed_fraction = view_variance / observed_variance)
  scores <- as_tibble(pca$x[, seq_len(n_saved_axes), drop = FALSE])
  score_rows[[view]] <- bind_cols(tibble(view), site, scores)
  loadings <- as_tibble(pca$rotation[, seq_len(n_saved_axes), drop = FALSE])
  loading_rows[[view]] <- bind_cols(select(profiles, database_row, transformation, mass), loadings) %>%
    pivot_longer(starts_with("PC"), names_to = "axis", values_to = "loading") %>%
    mutate(view, contribution_percent = 100 * loading^2, .before = 1)
  if (view == "observed") {
    matched <- match(site$site_code, previous_scores$site_code)
    validation_rows[[view]] <- tibble(check = c("observed_scores_reproduce_supporting_12",
      "observed_variance_reproduces_supporting_12"),
      passed = c(max(abs(as.matrix(scores[, 1:2]) -
        as.matrix(previous_scores[matched, c("pc1", "pc2")]))) < 1e-10,
        max(abs(percent - previous_variance$percent_variance)) < 1e-9))
  }
}
scores <- bind_rows(score_rows)
variance <- bind_rows(variance_rows)
loadings <- bind_rows(loading_rows) %>%
  left_join(select(motif_names, transformation = motif, compatible_change), by = "transformation") %>%
  mutate(display_label = if_else(is.na(compatible_change), transformation,
    paste0(compatible_change, " (", transformation, ")")))
write_csv(scores, file.path(results_dir, "site_pca_scores.csv"))
write_csv(variance, file.path(results_dir, "pca_variance.csv"))
write_csv(loadings, file.path(results_dir, "pca_loadings.csv"))
observed_scores <- scores %>% filter(view == "observed")
adjusted_scores <- scores %>% filter(view == "detection_adjusted")
stopifnot(identical(observed_scores$site_code, adjusted_scores$site_code))
axis_correspondence <- cor(as.matrix(observed_scores[, paste0("PC", seq_len(n_saved_axes))]),
  as.matrix(adjusted_scores[, paste0("PC", seq_len(n_saved_axes))]))
write_csv(as_tibble(axis_correspondence, rownames = "observed_axis") %>%
  pivot_longer(-observed_axis, names_to = "adjusted_axis", values_to = "pearson_r"),
  file.path(results_dir, "axis_correspondence.csv"))

# 4. Describe environmental gradients without treating correlations as tests ----
# Segment means give repeated sites equal segment weight in the main display.
# Correlations are descriptive, are not P values, and do not establish causation.
gradient_rows <- list()
for (unit in c("segment", "site")) {
  d <- scores
  if (unit == "segment") {
    d <- scores %>% group_by(view, site_segment_number) %>%
      summarize(across(all_of(c(paste0("PC", seq_len(n_saved_axes)),
        gradient_design$variable)), ~mean(.x, na.rm = TRUE)), .groups = "drop")
  }
  for (view in names(views)) {
    values <- d %>% filter(.data$view == .env$view)
    for (axis in paste0("PC", seq_len(n_saved_axes))) {
      for (j in seq_len(nrow(gradient_design))) {
        x <- values[[gradient_design$variable[j]]]
        y <- values[[axis]]
        included <- is.finite(x) & is.finite(y)
        gradient_rows[[length(gradient_rows) + 1]] <- tibble(view, unit, axis,
          variable = gradient_design$variable[j], label = gradient_design$label[j],
          units = sum(included), excluded_units = sum(!included),
          spearman_rho = cor(x[included], y[included], method = "spearman"))
      }
    }
  }
}
gradients <- bind_rows(gradient_rows)
write_csv(gradients, file.path(results_dir, "axis_gradient_correlations.csv"))

# 5. Plot ordinations, variance, and both directions of the leading-axis loadings -
ordinations <- list()
x_limits <- range(scores$PC1)
y_limits <- range(scores$PC2)
for (view in names(views)) {
  d <- scores %>% filter(.data$view == .env$view)
  v <- variance %>% filter(.data$view == .env$view)
  p <- ggplot(d, aes(PC1, PC2, color = network_group)) +
    geom_point(size = 2.7, alpha = 0.85) +
    scale_color_manual(values = group_colors, name = NULL) +
    coord_equal(xlim = x_limits, ylim = y_limits) +
    labs(x = sprintf("PC1 (%.1f%%)", v$percent_within_view[1]),
      y = sprintf("PC2 (%.1f%%)", v$percent_within_view[2])) + plot_theme
  ordinations[[view]] <- p
  ggsave(file.path(figures_dir, paste0("2016_transformation_pca_", view, ".pdf")),
    p, width = 6.5, height = 5, bg = "white")
  # A count-colored view exposes detection gradients directly.
  diagnostic <- ggplot(d, aes(PC1, PC2, color = log_detection)) +
    geom_point(size = 2.7, alpha = 0.85) +
    scale_color_viridis_c(name = "Detection count (log10)") +
    coord_equal(xlim = x_limits, ylim = y_limits) +
    labs(x = sprintf("PC1 (%.1f%%)", v$percent_within_view[1]),
      y = sprintf("PC2 (%.1f%%)", v$percent_within_view[2])) + plot_theme
  ggsave(file.path(figures_dir, paste0("2016_transformation_pca_", view, "_detection.pdf")),
    diagnostic, width = 6.5, height = 5, bg = "white")
  # Save all loadings in the table; display six from each sign rather than only
  # the largest absolute values, which can hide one side of the gradient.
  l <- loadings %>% filter(.data$view == .env$view, axis == "PC1") %>%
    mutate(direction = if_else(loading >= 0, "Positive", "Negative")) %>%
    group_by(direction) %>% slice_max(abs(loading), n = loadings_per_direction,
      with_ties = FALSE) %>% ungroup() %>% arrange(loading) %>%
    mutate(display_label = factor(display_label, levels = display_label))
  p <- ggplot(l, aes(loading, display_label, fill = direction)) +
    geom_col(width = 0.7) +
    scale_fill_manual(values = c(Negative = "#0072B2", Positive = "#E69F00"), guide = "none") +
    labs(x = "PC1 loading", y = NULL) + plot_theme
  ggsave(file.path(figures_dir, paste0("2016_transformation_pc1_loadings_", view, ".pdf")),
    p, width = 9, height = 5.5, bg = "white")
}
combined <- wrap_plots(ordinations, ncol = 2, guides = "collect") &
  theme(legend.position = "bottom")
ggsave(file.path(figures_dir, "2016_transformation_pca_comparison.pdf"),
  combined, width = 13, height = 5, bg = "white")
scree <- ggplot(filter(variance, axis <= n_scree_axes),
  aes(axis, percent_within_view, color = view)) +
  geom_line(linewidth = 0.6) + geom_point(size = 2) +
  scale_color_manual(values = c(observed = "#0072B2", detection_adjusted = "#E69F00"),
    labels = view_labels, name = NULL) +
  scale_x_continuous(breaks = seq_len(n_scree_axes)) +
  labs(x = "Principal component", y = "Variance within each profile view (%)") + plot_theme
ggsave(file.path(figures_dir, "2016_transformation_pca_scree.pdf"),
  scree, width = 6.5, height = 4.8, bg = "white")
gradient_plot_data <- gradients %>% filter(unit == "segment") %>%
  mutate(label = factor(label, levels = gradient_design$label),
    axis = factor(axis, levels = rev(paste0("PC", seq_len(n_saved_axes)))),
    view = factor(view, levels = names(view_labels), labels = view_labels))
gradient_plot <- ggplot(gradient_plot_data, aes(label, axis, fill = spearman_rho)) +
  geom_tile(color = "white", linewidth = 0.6) +
  geom_text(aes(label = sprintf("%.2f", spearman_rho)), size = 3.6) +
  scale_fill_gradient2(low = "#56B4E9", mid = "white", high = "#E69F00",
    midpoint = 0, limits = c(-1, 1), name = "Spearman rho") +
  facet_wrap(~view, ncol = 1) + labs(x = NULL, y = NULL) + plot_theme +
  theme(axis.text.x = element_text(angle = 25, hjust = 1))
ggsave(file.path(figures_dir, "2016_transformation_pca_gradient_correlations.pdf"),
  gradient_plot, width = 9, height = 5.8, bg = "white")

# 6. Check the retained geometry and unchanged source files ---------------------
integrity <- tibble(path = substring(input_paths, nchar(here()) + 2L),
  md5_before = input_md5, md5_after = unname(tools::md5sum(input_paths))) %>%
  mutate(unchanged = md5_before == md5_after)
validation <- bind_rows(validation_rows) %>% bind_rows(tibble(
  check = c("adjusted_profiles_orthogonal_to_detection_model", "loading_contributions_sum_to_100",
    "gradient_coverage_retained", "source_inputs_unchanged"),
  passed = c(max(abs(crossprod(nuisance, residual_profiles))) < 1e-8,
    all(abs((loadings %>% group_by(view, axis) %>%
      summarize(total = sum(contribution_percent), .groups = "drop"))$total - 100) < 1e-8),
    all(gradients$units >= 3), all(integrity$unchanged))))
write_csv(integrity, file.path(results_dir, "input_integrity.csv"))
write_csv(validation, file.path(results_dir, "numerical_validation.csv"))
stopifnot(all(validation$passed))
message("Transformation PCA completed for observed and detection-adjusted profiles.")
