# Targeted associations between potential enzymes and compatible formula differences.
# These exploratory comparisons do not identify enzyme substrates or reaction fluxes.

library(here)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(permute)
library(patchwork)

# 1. Settings, chemically motivated comparisons, and plotting -------------------
results_dir <- here("results", "fticr_2016", "enzyme_transformations")
figures_dir <- here("figures", "supplement", "enzyme_transformations")
n_permutations <- 9999L
permutation_seed <- 202610190L
mass_tolerance <- 0.000010
significance_threshold <- 0.05
comparison_design <- tribble(
  ~comparison, ~enzyme_variable, ~enzyme, ~motif, ~reference_label, ~C, ~H, ~O, ~N, ~S, ~P, ~Na,
  "glu_hexose", "sediment_glu_umol_g_hr", "GLU", "Hexose residue", "C6H10O5", 6, 10, 5, 0, 0, 0, 0,
  "lap_glycine", "sediment_lap_umol_g_hr", "LAP", "Glycine residue", "Glycine", 2, 3, 1, 1, 0, 0, 0,
  "lap_valine", "sediment_lap_umol_g_hr", "LAP", "Valine residue", "Valine", 5, 9, 1, 1, 0, 0, 0,
  "lap_leucine", "sediment_lap_umol_g_hr", "LAP", "Leucine/isoleucine residue", "Isoleucine", 6, 11, 1, 1, 0, 0, 0,
  "nag_hexosamine", "sediment_nag_umol_g_hr", "NAG", "N-acetylhexosamine residue", "glcnac_C8H13N1O5", 8, 13, 5, 1, 0, 0, 0,
  "ap_phosphate", "sediment_ap_umol_g_hr", "AP", "Phosphate group", "phosphate", 0, 1, 3, 0, 0, 1, 0
)
# Primary associations use square-root motif fractions of all published matches.
# Each sensitivity retains the six-comparison family; it is not a new discovery set.
scope_design <- tribble(
  ~scope, ~unit, ~pair_subset, ~denominator, ~role,
  "segment_primary", "segment", "all_compatible", "matched_peak_pairs", "primary",
  "site_sensitivity", "site", "all_compatible", "matched_peak_pairs", "sensitivity",
  "single_formula_sensitivity", "segment", "single_candidate", "matched_peak_pairs", "sensitivity",
  "possible_pair_sensitivity", "segment", "all_compatible", "possible_peak_pairs", "sensitivity"
)
group_colors <- c(Headwater = "#009E73", Intermediate = "#E69F00", Mainstem = "#0072B2")
plot_theme <- theme_bw(base_size = 11) +
  theme(panel.grid = element_blank(), strip.background = element_blank(),
    legend.position = "bottom")

# 2. Validate site identities and preserve source identity ----------------------
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)
input_paths <- c(
  here("results", "fticr_2016", "transformations", "site_summary.csv"),
  here("results", "fticr_2016", "transformations", "peak_pair_assignments.csv.gz"),
  here("results", "fticr_2016", "tables", "primary_peak_properties.csv"),
  here("data", "derived", "fticr_2016", "sediment_44_presence_absence.csv"),
  here("data", "derived", "analysis_inputs", "sediment_multiblock", "sediment_44_enzyme_activity.csv"),
  here("reference", "danczak_2020", "Transformation_Database_07-2020.csv"),
  here("results", "fticr_2016", "transformation_context", "site_formula_compatible_motifs.csv")
)
input_md5 <- unname(tools::md5sum(input_paths))
stopifnot(!anyNA(input_md5))
site <- read_csv(input_paths[1], col_types = cols(site_code = col_character()))
pairs <- read_csv(input_paths[2], show_col_types = FALSE) %>% filter(published_assignment)
peaks <- read_csv(input_paths[3], show_col_types = FALSE)
pa_table <- read_csv(input_paths[4], col_types = cols(site_code = col_character()))
enzymes <- read_csv(input_paths[5], col_types = cols(site_code = col_character()))
reference <- read_csv(input_paths[6], show_col_types = FALSE)
previous_motifs <- read_csv(input_paths[7], col_types = cols(site_code = col_character()))
stopifnot(!anyDuplicated(site$site_code), !anyDuplicated(enzymes$site_code),
  !anyDuplicated(pairs$pair_id), identical(site$site_code, pa_table$site_code),
  setequal(site$site_code, enzymes$site_code), identical(peaks$peak_id, names(pa_table)[-1]))
site <- site %>% left_join(enzymes, by = "site_code") %>%
  mutate(network_group = case_when(site_stream_order <= 2 ~ "Headwater",
    site_stream_order <= 4 ~ "Intermediate", site_stream_order == 5 ~ "Mainstem"))
segment_check <- site %>% group_by(site_segment_number) %>%
  summarize(groups = n_distinct(network_group), .groups = "drop")
stopifnot(nrow(site) == 44, all(segment_check$groups == 1),
  all(site$sediment_organic_content_percent > 0), all(site$site_drainage_area_ha > 0))
pa <- as.matrix(pa_table[, -1])
lower <- match(pairs$lower_peak_id, peaks$peak_id)
upper <- match(pairs$upper_peak_id, peaks$peak_id)
stopifnot(!anyNA(lower), !anyNA(upper), all(rowSums(pa) == site$detected_features))
co_detected <- pa[, lower, drop = FALSE] > 0 & pa[, upper, drop = FALSE] > 0
stopifnot(all(colSums(co_detected) == pairs$observed_sites),
  all(rowSums(co_detected) == site$matched_peak_pairs))

# 3. Require both the measured mass difference and exact elemental difference ----
# Leucine and isoleucine share a residue formula and cannot be distinguished here.
# Hexosamine refers to an N-acetylhexosamine residue, not a confirmed structure.
element_columns <- c(C = "carbon_count", H = "hydrogen_count", O = "oxygen_count",
  N = "nitrogen_count", S = "sulfur_count", P = "phosphorus_count", Na = "sodium_count")
delta <- as.matrix(peaks[upper, element_columns]) - as.matrix(peaks[lower, element_columns])
colnames(delta) <- names(element_columns)
single_candidate <- peaks$candidate_count[lower] == 1 & peaks$candidate_count[upper] == 1
comparison_design$mass <- reference$Mass[match(comparison_design$reference_label, reference$Name)]
stopifnot(!anyNA(comparison_design$mass))
assignment_rows <- list()
coverage_rows <- list()
input_rows <- list()
audit_rows <- list()
for (j in seq_len(nrow(comparison_design))) {
  design <- comparison_design[j, ]
  mass_match <- pairs$observed_difference + mass_tolerance >= design$mass &
    pairs$observed_difference - mass_tolerance <= design$mass
  formula_match <- rowSums(sweep(delta, 2,
    as.numeric(design[, names(element_columns)]), "!=") != 0) == 0
  compatible <- mass_match & formula_match
  compatible_single <- compatible & single_candidate
  motif_pairs <- rowSums(co_detected[, compatible, drop = FALSE])
  single_pairs <- rowSums(co_detected[, compatible_single, drop = FALSE])
  assignment_rows[[j]] <- pairs[compatible, ] %>%
    mutate(comparison = design$comparison, single_formula_candidates = single_candidate[compatible],
      .before = 1)
  coverage_rows[[j]] <- design %>% mutate(
    mass_matched_distinct_pairs = sum(mass_match), compatible_distinct_pairs = sum(compatible),
    single_candidate_distinct_pairs = sum(compatible_single),
    sites_with_compatible_pairs = sum(motif_pairs > 0),
    sites_with_single_candidate_pairs = sum(single_pairs > 0))
  d <- site %>% mutate(comparison = design$comparison, enzyme = design$enzyme,
    motif = design$motif, enzyme_raw = .data[[design$enzyme_variable]],
    compatible_pairs = motif_pairs, single_candidate_pairs = single_pairs,
    fraction_all_matches = compatible_pairs / matched_peak_pairs,
    single_fraction_all_matches = single_candidate_pairs / matched_peak_pairs,
    fraction_possible_pairs = compatible_pairs / possible_peak_pairs)
  eligible <- is.finite(d$enzyme_raw) & d$enzyme_raw >= 0 &
    is.finite(d$sediment_organic_content_percent) & d$sediment_organic_content_percent > 0 &
    is.finite(d$site_drainage_area_ha) & d$site_drainage_area_ha > 0 &
    is.finite(d$detected_features) & d$detected_features > 0
  audit_rows[[j]] <- d %>% transmute(comparison, site_code, sediment_sample_id,
    site_segment_number, included = eligible,
    exclusion_reason = if_else(eligible, "included", "missing_or_invalid_required_predictor"))
  # Define this enzyme's scale on its own eligible site pool before segment means.
  enzyme_scale <- median(d$enzyme_raw[eligible & d$enzyme_raw > 0])
  stopifnot(is.finite(enzyme_scale), enzyme_scale > 0)
  input_rows[[j]] <- d %>% filter(eligible) %>%
    transmute(comparison, enzyme, motif, site_code, sediment_sample_id, site_segment_number,
      network_group, detected_features, matched_peak_pairs, possible_peak_pairs,
      compatible_pairs, single_candidate_pairs, fraction_all_matches,
      single_fraction_all_matches, fraction_possible_pairs, enzyme_raw, enzyme_scale,
      enzyme_transformed = asinh(enzyme_raw / enzyme_scale),
      log_detection = log10(detected_features),
      log_detection_squared = log_detection^2,
      log_area = log10(site_drainage_area_ha),
      log_organic = log10(sediment_organic_content_percent))
}
model_inputs <- bind_rows(input_rows)
coverage <- bind_rows(coverage_rows)
write_csv(bind_rows(assignment_rows), file.path(results_dir, "targeted_pair_assignments.csv.gz"))
write_csv(coverage, file.path(results_dir, "motif_assignment_audit.csv"))
write_csv(model_inputs, file.path(results_dir, "site_enzyme_motif_inputs.csv"))
write_csv(bind_rows(audit_rows), file.path(results_dir, "model_inclusion_audit.csv"))
# Four existing motifs must reproduce supporting 13 without numerical change.
previous_names <- c(glu_hexose = "C6H10O5", lap_glycine = "Glycine residue",
  lap_valine = "Valine residue", ap_phosphate = "HPO3")
reproduced <- model_inputs %>% filter(comparison %in% names(previous_names)) %>%
  mutate(previous_motif = unname(previous_names[comparison])) %>%
  left_join(select(previous_motifs, site_code, previous_motif = motif, previous_pairs = pairs),
    by = c("site_code", "previous_motif"))
stopifnot(nrow(reproduced) == sum(model_inputs$comparison %in% names(previous_names)),
  !anyNA(reproduced$previous_pairs), all(reproduced$compatible_pairs == reproduced$previous_pairs))

# 4. Fit partial slopes and permute reduced-model residuals ---------------------
# Null: enzyme activity adds no linear association after the four named covariates.
# Freedman-Lane permutations retain nuisance fitted values and shuffle residuals
# among segments (or sites in the site-level sensitivity). They do not preserve
# all river-network autocorrelation. Tests are two-sided because pair inventories
# do not distinguish substrate depletion from product accumulation.
fit_association <- function(d, permutations = NULL) {
  reduced <- lm(response ~ log_detection + log_detection_squared + log_area + log_organic,
    data = d)
  full <- lm(response ~ log_detection + log_detection_squared + log_area + log_organic +
    enzyme_transformed, data = d)
  coefficients <- coef(summary(full))["enzyme_transformed", ]
  enzyme_residual <- qr.resid(reduced$qr, d$enzyme_transformed)
  response_residual <- resid(reduced)
  stopifnot(full$rank == ncol(model.matrix(full)), sd(response_residual) > 0,
    sd(enzyme_residual) > 0)
  interval <- confint(full, "enzyme_transformed", level = 0.95)
  standardizer <- sd(d$enzyme_transformed) / sd(d$response)
  p_permutation <- NA_real_
  permuted_t <- numeric()
  if (!is.null(permutations)) {
    permuted <- matrix(response_residual[t(permutations)], nrow = nrow(d))
    permuted <- sweep(permuted, 1, fitted(reduced), "+")
    permuted_residual <- qr.resid(reduced$qr, permuted)
    sum_x_squared <- sum(enzyme_residual^2)
    slopes <- drop(crossprod(enzyme_residual, permuted_residual)) / sum_x_squared
    errors <- permuted_residual - tcrossprod(enzyme_residual, slopes)
    standard_errors <- sqrt(colSums(errors^2) / df.residual(full) / sum_x_squared)
    permuted_t <- slopes / standard_errors
    p_permutation <- (1 + sum(abs(permuted_t) >= abs(coefficients["t value"]) - 1e-12)) /
      (nrow(permutations) + 1)
  }
  statistics <- tibble(units = nrow(d), nuisance_rank = reduced$rank,
    residual_df = df.residual(full), slope = unname(coefficients["Estimate"]),
    slope_se = unname(coefficients["Std. Error"]),
    slope_lower_95 = interval[1], slope_upper_95 = interval[2],
    standardized_slope = slope * standardizer,
    standardized_lower_95 = slope_lower_95 * standardizer,
    standardized_upper_95 = slope_upper_95 * standardizer,
    partial_r = cor(enzyme_residual, response_residual),
    p_permutation, max_cooks_distance = max(cooks.distance(full)),
    influential_unit = d$unit_id[which.max(cooks.distance(full))],
    condition_number = kappa(scale(model.matrix(full)[, -1]), exact = TRUE))
  list(statistics = statistics, permutation_t = permuted_t, residuals = d %>% mutate(
    enzyme_residual = enzyme_residual / sd(enzyme_residual),
    response_residual = response_residual / sd(response_residual)))
}

# 5. Run the declared six-test family and its three sensitivities ----------------
test_rows <- list()
residual_rows <- list()
deletion_rows <- list()
primary_units <- list()
for (scope_index in seq_len(nrow(scope_design))) {
  scope <- scope_design[scope_index, ]
  for (j in seq_len(nrow(comparison_design))) {
    design <- comparison_design[j, ]
    d <- model_inputs %>% filter(comparison == design$comparison)
    numerator <- d$compatible_pairs
    if (scope$pair_subset == "single_candidate") numerator <- d$single_candidate_pairs
    d$response <- sqrt(numerator / d[[scope$denominator]])
    if (scope$unit == "segment") {
      d <- d %>% group_by(site_segment_number, network_group) %>%
        summarize(across(c(response, enzyme_transformed, log_detection,
          log_detection_squared, log_area, log_organic), mean),
          sites = n(), .groups = "drop") %>%
        mutate(unit_id = as.character(site_segment_number))
    } else {
      d <- d %>% mutate(unit_id = site_code, sites = 1L)
    }
    seed <- permutation_seed + 100L * scope_index + j
    set.seed(seed)
    permutations <- shuffleSet(nrow(d), nset = n_permutations)
    fit <- fit_association(d, permutations)
    test_rows[[length(test_rows) + 1]] <- bind_cols(scope, design[, 1:4],
      tibble(seed, requested_permutations = n_permutations,
        actual_permutations = nrow(permutations)), fit$statistics)
    if (scope$role == "primary") {
      primary_units[[design$comparison]] <- d
      residual_rows[[j]] <- fit$residuals %>% mutate(comparison = design$comparison)
      for (unit in d$unit_id) {
        reduced_data <- d[d$unit_id != unit, ]
        deleted <- fit_association(reduced_data)$statistics
        deletion_rows[[length(deletion_rows) + 1]] <- deleted %>%
          mutate(comparison = design$comparison, removed_segment = unit, .before = 1)
      }
    }
  }
}
tests <- bind_rows(test_rows) %>% group_by(scope) %>%
  mutate(p_bh = p.adjust(p_permutation, method = "BH"), family_size = n()) %>% ungroup()
stopifnot(nrow(tests) == 24, all(tests$family_size == 6),
  all(is.finite(tests$partial_r)), all(tests$p_permutation > 0 & tests$p_permutation <= 1))
write_csv(tests, file.path(results_dir, "targeted_association_tests.csv"))
write_csv(bind_rows(deletion_rows), file.path(results_dir, "leave_one_segment_out.csv"))

# 6. Plot partial associations, adding lines only for supported primary slopes ---
primary <- tests %>% filter(role == "primary")
all_residuals <- bind_rows(residual_rows)
x_limits <- range(all_residuals$enzyme_residual)
y_limits <- range(all_residuals$response_residual)
plots <- list()
for (j in seq_len(nrow(comparison_design))) {
  design <- comparison_design[j, ]
  d <- residual_rows[[j]]
  result <- primary %>% filter(comparison == design$comparison)
  d$panel_label <- paste0(design$enzyme, ": ", design$motif)
  p <- ggplot(d, aes(enzyme_residual, response_residual, color = network_group)) +
    geom_hline(yintercept = 0, color = "#D9D9D9", linewidth = 0.3) +
    geom_vline(xintercept = 0, color = "#D9D9D9", linewidth = 0.3) +
    geom_point(size = 2.2, alpha = 0.85) +
    coord_cartesian(xlim = x_limits, ylim = y_limits) +
    scale_color_manual(values = group_colors, name = NULL) +
    labs(x = "Enzyme activity (adjusted, SD)",
      y = "Compatible-pair fraction (adjusted, SD)") +
    facet_wrap(~panel_label) + plot_theme
  if (result$p_bh < significance_threshold) {
    p <- p + geom_abline(intercept = 0, slope = result$partial_r,
      color = "black", linewidth = 0.5)
  }
  plots[[j]] <- p
  ggsave(file.path(figures_dir, paste0("2016_enzyme_", design$comparison, ".pdf")),
    p, width = 5.1, height = 4.5, bg = "white")
}
combined <- wrap_plots(plots, ncol = 3, guides = "collect") & theme(legend.position = "bottom")
ggsave(file.path(figures_dir, "2016_targeted_enzyme_transformations.pdf"),
  combined, width = 15.3, height = 8.5, bg = "white")

# 7. Check permutation calculations against direct refits and source integrity --
# Direct lm refits verify the vectorized reduced-residual permutation statistic.
d <- primary_units[[comparison_design$comparison[1]]]
set.seed(permutation_seed)
validation_permutations <- shuffleSet(nrow(d), nset = 99L)
optimized <- fit_association(d, validation_permutations)
reduced <- lm(response ~ log_detection + log_detection_squared + log_area + log_organic, data = d)
full <- lm(response ~ log_detection + log_detection_squared + log_area + log_organic +
  enzyme_transformed, data = d)
observed_t <- coef(summary(full))["enzyme_transformed", "t value"]
direct_t <- numeric(nrow(validation_permutations))
for (i in seq_len(nrow(validation_permutations))) {
  d$permuted_response <- fitted(reduced) + resid(reduced)[validation_permutations[i, ]]
  direct_fit <- lm(permuted_response ~ log_detection + log_detection_squared + log_area +
    log_organic + enzyme_transformed, data = d)
  direct_t[i] <- coef(summary(direct_fit))["enzyme_transformed", "t value"]
}
direct_p <- (1 + sum(abs(direct_t) >= abs(observed_t) - 1e-12)) / (length(direct_t) + 1)
integrity <- tibble(path = substring(input_paths, nchar(here()) + 2L),
  md5_before = input_md5, md5_after = unname(tools::md5sum(input_paths))) %>%
  mutate(unchanged = md5_before == md5_after)
write_csv(integrity, file.path(results_dir, "input_integrity.csv"))
validation <- tibble(check = c("existing_motif_counts_reproduced", "permutation_direct_refit_agreement",
  "six_comparisons_per_family", "source_inputs_unchanged"),
  passed = c(all(reproduced$compatible_pairs == reproduced$previous_pairs),
    abs(optimized$statistics$p_permutation - direct_p) < 1e-12 &
      max(abs(optimized$permutation_t - direct_t)) < 1e-8,
    all(tests$family_size == 6), all(integrity$unchanged)))
write_csv(validation, file.path(results_dir, "numerical_validation.csv"))
writeLines(capture.output(sessionInfo()), file.path(results_dir, "session_info.txt"))
stopifnot(all(validation$passed))
message("Targeted enzyme comparisons: ", sum(primary$p_bh < significance_threshold),
  " of ", nrow(primary), " primary associations supported after BH correction.")
