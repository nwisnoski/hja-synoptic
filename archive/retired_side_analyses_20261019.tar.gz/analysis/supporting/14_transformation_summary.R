# Descriptive catalogue of Danczak mass-difference matches and assignment checks.
# Uses completed outputs from supporting 12 and the motif checks in supporting 13.

library(here)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)

# 1. Settings and readable descriptions -----------------------------------------
results_dir <- here("results", "fticr_2016", "transformations")
context_dir <- here("results", "fticr_2016", "transformation_context")
figures_dir <- here("figures", "supplement", "transformations")
motif_descriptions <- tribble(
  ~motif, ~compatible_change,
  "H2", "Hydrogen gain/loss",
  "O", "Oxygen gain/loss",
  "H2O", "Water gain/loss",
  "CO2", "Carboxyl-group equivalent",
  "CH2", "CH2 homologous-series difference",
  "NH2", "Amino-group equivalent",
  "HPO3", "Phosphate-group equivalent",
  "SO3", "SO3 gain/loss",
  "C6H10O5", "Hexose-residue equivalent",
  "C2H2O", "Acetyl-residue equivalent",
  "Glycine residue", "Glycine-residue equivalent",
  "Valine residue", "Valine-residue equivalent"
)
support_colors <- c(
  "Compatible; single formula candidates" = "#0072B2",
  "Compatible; multiple formula candidates" = "#E69F00",
  "Mass match; incompatible assigned formulas" = "#D9D9D9"
)
plot_theme <- theme_bw(base_size = 12) +
  theme(panel.grid = element_blank(), strip.background = element_blank())

# 2. Read the completed pair assignments, counts, and motif checks ---------------
input_paths <- c(
  file.path(results_dir, "transformation_profiles.csv"),
  file.path(results_dir, "peak_pair_assignments.csv.gz"),
  file.path(context_dir, "motif_formula_audit.csv"),
  file.path(context_dir, "site_formula_compatible_motifs.csv")
)
input_md5 <- unname(tools::md5sum(input_paths))
stopifnot(!anyNA(input_md5))
profiles <- read_csv(input_paths[1], show_col_types = FALSE)
assignments <- read_csv(input_paths[2], show_col_types = FALSE)
motifs <- read_csv(input_paths[3], show_col_types = FALSE)
site_motifs <- read_csv(input_paths[4], col_types = cols(site_code = col_character()))
counts <- as.matrix(profiles[, -(1:3)])
stopifnot(ncol(counts) == 44, all(colSums(counts) > 0))

# 3. Rank every database label, retaining overwritten alternative annotations ----
# A repeated peak pair is counted once across sites in the distinct-pair columns.
# Sample-pair counts and mean fractions describe occurrence, not reaction evidence.
candidate_summary <- assignments %>% group_by(database_row) %>% summarize(
  candidate_distinct_pairs = n(),
  pairs_with_alternative_labels = sum(candidate_assignments > 1),
  median_absolute_mass_error = median(abs(mass_error)), .groups = "drop")
published_summary <- assignments %>% filter(published_assignment) %>%
  count(database_row, name = "published_distinct_pairs")
catalogue <- profiles %>% select(database_row, transformation, mass) %>%
  mutate(
    sites_with_published_matches = rowSums(counts > 0),
    sample_pair_matches = rowSums(counts),
    mean_sample_pair_fraction = rowMeans(sweep(counts, 2, colSums(counts), "/"))
  ) %>%
  left_join(published_summary, by = "database_row") %>%
  left_join(candidate_summary, by = "database_row") %>%
  mutate(across(c(published_distinct_pairs, candidate_distinct_pairs,
    pairs_with_alternative_labels), ~coalesce(.x, 0L))) %>%
  arrange(desc(mean_sample_pair_fraction), database_row) %>%
  mutate(rank = row_number(), .before = 1)
write_csv(catalogue, file.path(results_dir, "transformation_label_catalogue.csv"))

# 4. Summarize the interpretable subset by frequency and formula-assignment checks
coverage <- site_motifs %>% group_by(motif) %>% summarize(
  sites_with_compatible_pairs = sum(pairs > 0),
  compatible_sample_pair_matches = sum(pairs),
  mean_sample_pair_fraction = mean(fraction_all_matches), .groups = "drop")
motif_summary <- motifs %>%
  left_join(motif_descriptions, by = "motif") %>%
  left_join(coverage, by = "motif") %>%
  transmute(motif, compatible_change, reference_label, mass,
    mass_matched_distinct_pairs = mass_matched_pairs,
    formula_compatible_distinct_pairs = compatible_pairs,
    compatible_single_candidate_pairs,
    compatible_multiple_candidate_pairs = compatible_pairs - compatible_single_candidate_pairs,
    mass_only_incompatible_pairs = mass_matched_pairs - compatible_pairs,
    sites_with_compatible_pairs, compatible_sample_pair_matches, mean_sample_pair_fraction) %>%
  arrange(desc(mass_matched_distinct_pairs))
stopifnot(!anyNA(motif_summary),
  all(motif_summary$compatible_multiple_candidate_pairs >= 0),
  all(motif_summary$mass_only_incompatible_pairs >= 0),
  sum(catalogue$published_distinct_pairs) == n_distinct(assignments$pair_id),
  sum(catalogue$sample_pair_matches) == sum(counts))
write_csv(motif_summary, file.path(results_dir, "interpretable_motif_summary.csv"))

# 5. Plot occurrence and assignment checks without assigning reaction confidence -
support_labels <- setNames(
  paste0(motif_summary$compatible_change, " (",
    recode(motif_summary$motif, "Glycine residue" = "C2H3NO",
      "Valine residue" = "C5H9NO"), ")"),
  motif_summary$motif)
support_distribution <- motif_summary %>%
  select(motif, compatible_single_candidate_pairs, compatible_multiple_candidate_pairs,
    mass_only_incompatible_pairs) %>%
  pivot_longer(-motif, names_to = "assignment_check", values_to = "distinct_pairs") %>%
  mutate(
    assignment_check = factor(assignment_check,
      levels = c("compatible_single_candidate_pairs", "compatible_multiple_candidate_pairs",
        "mass_only_incompatible_pairs"), labels = names(support_colors)),
    motif = factor(motif, levels = rev(motif_summary$motif))
  )
support_plot <- ggplot(support_distribution,
  aes(distinct_pairs, motif, fill = assignment_check)) +
  geom_col(width = 0.72, position = position_stack(reverse = TRUE)) +
  scale_y_discrete(labels = support_labels) +
  scale_fill_manual(values = support_colors, name = NULL) +
  labs(x = "Distinct mass-matched peak pairs across 44 profiles", y = NULL) +
  plot_theme + theme(legend.position = "bottom",
    legend.text = element_text(size = 10), legend.key.height = grid::unit(0.35, "cm")) +
  guides(fill = guide_legend(ncol = 1))
ggsave(file.path(figures_dir, "2016_transformation_assignment_summary.pdf"),
  support_plot, width = 11.5, height = 6.5, bg = "white")

rank_plot <- ggplot(filter(catalogue, sample_pair_matches > 0),
  aes(rank, mean_sample_pair_fraction)) +
  geom_point(size = 1.4, color = "#0072B2", alpha = 0.7) +
  scale_x_log10() +
  scale_y_log10(labels = scales::label_percent()) +
  labs(x = "Published transformation-label rank", y = "Mean fraction of matched pairs") +
  plot_theme
ggsave(file.path(figures_dir, "2016_transformation_label_rank_distribution.pdf"),
  rank_plot, width = 6, height = 4.8, bg = "white")

# 6. Preserve source identity ---------------------------------------------------
integrity <- tibble(path = substring(input_paths, nchar(here()) + 2L),
  md5_before = input_md5, md5_after = unname(tools::md5sum(input_paths))) %>%
  mutate(unchanged = md5_before == md5_after)
write_csv(integrity, file.path(results_dir, "summary_input_integrity.csv"))
stopifnot(all(integrity$unchanged))
message("Descriptive summary: ", sum(catalogue$sample_pair_matches > 0),
  " published labels; ", nrow(motif_summary), " interpretable motifs with assignment checks.")
