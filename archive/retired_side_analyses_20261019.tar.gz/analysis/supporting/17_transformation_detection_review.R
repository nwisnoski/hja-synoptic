# Revisit transformation signals with and without detection-count conditioning.
# Keep sample weighting, chemical assignments, and the other covariates fixed.

library(here)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(vegan)
library(permute)
library(patchwork)

# 1. Settings, paired adjustment choices, and plotting --------------------------
results_dir <- here("results", "fticr_2016", "transformation_detection_review")
figures_dir <- here("figures", "supplement", "transformation_detection_review")
n_permutations <- 9999L
target_seed <- 202610190L
profile_seed <- 202610180L
significance_threshold <- 0.05
adjustment_design <- tribble(
  ~adjustment, ~target_conditions, ~profile_detection,
  "without_detection", "log_area + log_organic", "",
  "with_detection", "log_detection + log_detection_squared + log_area + log_organic",
  "log_detection + I(log_detection^2)"
)
target_scopes <- tribble(
  ~scope, ~unit, ~pair_subset, ~denominator, ~role,
  "segment_primary", "segment", "all_compatible", "matched_peak_pairs", "primary",
  "site_sensitivity", "site", "all_compatible", "matched_peak_pairs", "sensitivity",
  "single_formula_sensitivity", "segment", "single_candidate", "matched_peak_pairs", "sensitivity",
  "possible_pair_sensitivity", "segment", "all_compatible", "possible_peak_pairs", "sensitivity"
)
profile_scopes <- tribble(
  ~scope, ~pool, ~unit,
  "all_44_sites", "all", "site",
  "all_35_segments", "all", "segment",
  "matched_33_sites", "matched", "site",
  "matched_segments", "matched", "segment"
)
profile_design <- tribble(
  ~model, ~tested, ~other_conditions, ~previous_model,
  "network", "network_group", "", "network_detection",
  "network_beyond_classes", "network_group", "CLASS", "network_broad_classes",
  "enzymes", "enzyme_pc1 + enzyme_pc2", "", NA_character_,
  "enzymes_beyond_classes", "enzyme_pc1 + enzyme_pc2", "network_group + CLASS", "enzyme_beyond_classes"
)
group_colors <- c(Headwater = "#009E73", Intermediate = "#E69F00", Mainstem = "#0072B2")
plot_theme <- theme_bw(base_size = 11) +
  theme(panel.grid = element_blank(), strip.background = element_blank(),
    legend.position = "bottom")

# 2. Read the completed, audited inputs; retain earlier model outputs for checks -
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)
input_paths <- c(
  here("results", "fticr_2016", "enzyme_transformations", "site_enzyme_motif_inputs.csv"),
  here("results", "fticr_2016", "enzyme_transformations", "targeted_association_tests.csv"),
  here("results", "fticr_2016", "transformations", "transformation_profiles.csv"),
  here("results", "fticr_2016", "transformations", "site_summary.csv"),
  here("data", "derived", "sediment_characteristics_2016", "response_pool_model_inputs.csv"),
  here("results", "fticr_2016", "river_composition", "site_class_fractions.csv"),
  here("results", "fticr_2016", "transformation_context", "conditional_profile_tests.csv"),
  here("results", "fticr_2016", "matched_sediment_dispersion", "matched_site_manifest.csv"),
  here("results", "fticr_2016", "transformation_gradients", "site_pca_scores.csv"),
  here("results", "fticr_2016", "transformation_gradients", "pca_variance.csv")
)
input_md5 <- unname(tools::md5sum(input_paths))
stopifnot(!anyNA(input_md5))
target_inputs <- read_csv(input_paths[1], col_types = cols(site_code = col_character()))
previous_targets <- read_csv(input_paths[2], show_col_types = FALSE)
profiles <- read_csv(input_paths[3], show_col_types = FALSE)
site <- read_csv(input_paths[4], col_types = cols(site_code = col_character()))
enzyme_models <- read_csv(input_paths[5], col_types = cols(site_code = col_character())) %>%
  filter(pool == "molecular")
classes <- read_csv(input_paths[6], col_types = cols(site_code = col_character())) %>%
  select(site_code, source_class, fraction_detected) %>%
  pivot_wider(names_from = source_class, values_from = fraction_detected)
previous_profiles <- read_csv(input_paths[7], show_col_types = FALSE)
matched <- read_csv(input_paths[8], col_types = cols(site_code = col_character()))
scores <- read_csv(input_paths[9], col_types = cols(site_code = col_character())) %>%
  filter(view == "observed")
variance <- read_csv(input_paths[10], show_col_types = FALSE) %>% filter(view == "observed")
target_design <- previous_targets %>% select(comparison, enzyme, motif) %>% distinct()
site <- site %>% mutate(network_group = factor(case_when(site_stream_order <= 2 ~ "Headwater",
  site_stream_order <= 4 ~ "Intermediate", site_stream_order == 5 ~ "Mainstem"),
  levels = names(group_colors)), log_detection = log10(detected_features)) %>%
  left_join(select(enzyme_models, site_code, enzyme_pc1, enzyme_pc2), by = "site_code")
counts <- t(as.matrix(profiles[, site$site_code]))
hellinger <- sqrt(counts / rowSums(counts))
class_matrix <- as.matrix(classes[match(site$site_code, classes$site_code), -1])
stopifnot(nrow(site) == 44, nrow(target_design) == 6, !anyDuplicated(site$site_code),
  !anyNA(site), !anyNA(class_matrix), all(rowSums(counts) == site$matched_peak_pairs),
  all(abs(rowSums(class_matrix) - 1) < 1e-12),
  all(target_inputs$site_code %in% site$site_code))
write_csv(target_inputs %>% select(comparison, site_code, sediment_sample_id,
  site_segment_number) %>% mutate(included = TRUE),
  file.path(results_dir, "target_inclusion_audit.csv"))

# 3. Refit the same six targeted comparisons with paired residual permutations --
# Use the original permutations for each scope/comparison in both adjustments.
# The only removed terms are log detection and its square. Enzymes are potential
# activities per g AFDM per hour (Ward et al. 2019), transformed in supporting 15.
fit_target <- function(d, conditions, permutations = NULL) {
  reduced <- lm(as.formula(paste("response ~", conditions)), data = d)
  full <- lm(as.formula(paste("response ~", conditions, "+ enzyme_transformed")), data = d)
  coefficient <- coef(summary(full))["enzyme_transformed", ]
  x <- qr.resid(reduced$qr, d$enzyme_transformed)
  y <- resid(reduced)
  interval <- confint(full, "enzyme_transformed")
  stopifnot(full$rank == ncol(model.matrix(full)), sd(x) > 0, sd(y) > 0)
  p_value <- NA_real_
  permutation_t <- numeric()
  if (!is.null(permutations)) {
    permuted_y <- matrix(y[t(permutations)], nrow = nrow(d))
    permuted_y <- sweep(permuted_y, 1, fitted(reduced), "+")
    residual_y <- qr.resid(reduced$qr, permuted_y)
    slopes <- drop(crossprod(x, residual_y)) / sum(x^2)
    errors <- residual_y - tcrossprod(x, slopes)
    permutation_t <- slopes / sqrt(colSums(errors^2) / df.residual(full) / sum(x^2))
    p_value <- (1 + sum(abs(permutation_t) >= abs(coefficient["t value"]) - 1e-12)) /
      (nrow(permutations) + 1)
  }
  standardizer <- sd(d$enzyme_transformed) / sd(d$response)
  statistics <- tibble(units = nrow(d), residual_df = df.residual(full),
    slope = unname(coefficient["Estimate"]), slope_se = unname(coefficient["Std. Error"]),
    lower_95 = interval[1], upper_95 = interval[2],
    standardized_slope = slope * standardizer,
    standardized_lower_95 = lower_95 * standardizer,
    standardized_upper_95 = upper_95 * standardizer,
    partial_r = cor(x, y), p_value,
    max_cooks_distance = max(cooks.distance(full)),
    influential_unit = d$unit_id[which.max(cooks.distance(full))])
  list(statistics = statistics, permutation_t = permutation_t,
    residuals = d %>% mutate(enzyme_residual = x / sd(x), motif_residual = y / sd(y)))
}
target_rows <- list()
deletion_rows <- list()
plot_residuals <- list()
primary_units <- list()
for (s in seq_len(nrow(target_scopes))) {
  scope <- target_scopes[s, ]
  for (j in seq_len(nrow(target_design))) {
    design <- target_design[j, ]
    d <- target_inputs %>% filter(comparison == design$comparison)
    numerator <- d$compatible_pairs
    if (scope$pair_subset == "single_candidate") numerator <- d$single_candidate_pairs
    d$response <- sqrt(numerator / d[[scope$denominator]])
    if (scope$unit == "segment") {
      d <- d %>% group_by(site_segment_number, network_group) %>%
        summarize(across(c(response, enzyme_transformed, log_detection,
          log_detection_squared, log_area, log_organic), mean), .groups = "drop") %>%
        mutate(unit_id = as.character(site_segment_number))
    } else {
      d <- d %>% mutate(unit_id = site_code)
    }
    seed <- target_seed + 100L * s + j
    set.seed(seed)
    permutations <- shuffleSet(nrow(d), nset = n_permutations)
    for (a in seq_len(nrow(adjustment_design))) {
      adjustment <- adjustment_design[a, ]
      fit <- fit_target(d, adjustment$target_conditions, permutations)
      target_rows[[length(target_rows) + 1]] <- bind_cols(scope, design,
        select(adjustment, adjustment, conditions = target_conditions), tibble(seed), fit$statistics)
      if (scope$role == "primary" & adjustment$adjustment == "without_detection") {
        primary_units[[design$comparison]] <- d
        plot_residuals[[design$comparison]] <- fit$residuals
        for (unit in d$unit_id) {
          deleted <- fit_target(d[d$unit_id != unit, ], adjustment$target_conditions)$statistics
          deletion_rows[[length(deletion_rows) + 1]] <- deleted %>% select(-p_value) %>%
            mutate(comparison = design$comparison, removed_segment = unit, .before = 1)
        }
      }
    }
  }
}
target_tests <- bind_rows(target_rows) %>% group_by(scope, adjustment) %>%
  mutate(p_bh = p.adjust(p_value, "BH"), family_size = n()) %>% ungroup()
write_csv(target_tests, file.path(results_dir, "targeted_tests.csv"))
write_csv(bind_rows(deletion_rows), file.path(results_dir, "target_leave_one_segment_out.csv"))
target_reproduction <- target_tests %>% filter(adjustment == "with_detection") %>%
  left_join(previous_targets %>% select(scope, comparison, previous_r = partial_r,
    previous_slope = slope, previous_p = p_permutation, previous_q = p_bh),
    by = c("scope", "comparison"))

# 4. Refit whole-profile questions on the original site and segment geometries ---
# Four declared endpoints form the same BH family in each paired adjustment.
# The added overall enzyme test asks about the full profile before conditioning
# on broad molecular classes; the beyond-class endpoint reproduces supporting 13.
profile_rows <- list()
profile_audit <- list()
profile_deletions <- list()
geometry_rows <- list()
for (s in seq_len(nrow(profile_scopes))) {
  scope <- profile_scopes[s, ]
  included <- rep(TRUE, nrow(site))
  if (scope$pool == "matched") included <- site$site_code %in% matched$site_code
  d <- site[included, ]
  response <- hellinger[included, , drop = FALSE]
  class_values <- class_matrix[included, , drop = FALSE]
  profile_audit[[s]] <- site %>% transmute(scope = scope$scope, site_code,
    site_segment_number, included = included)
  if (scope$unit == "segment") {
    indices <- split(seq_len(nrow(d)), factor(d$site_segment_number))
    response <- t(vapply(indices, function(i) colMeans(response[i, , drop = FALSE]),
      numeric(ncol(response))))
    class_values <- t(vapply(indices, function(i) colMeans(class_values[i, , drop = FALSE]),
      numeric(ncol(class_values))))
    rows <- list()
    for (k in seq_along(indices)) {
      i <- indices[[k]]
      stopifnot(n_distinct(d$network_group[i]) == 1)
      rows[[k]] <- d[i[1], ] %>% mutate(log_detection = mean(d$log_detection[i]),
        enzyme_pc1 = mean(d$enzyme_pc1[i]), enzyme_pc2 = mean(d$enzyme_pc2[i]))
    }
    d <- bind_rows(rows)
  }
  # All nonzero PCA coordinates preserve Euclidean geometry and every RDA test.
  # This reduces permutation cost without selecting only the leading PCs.
  response_pca <- prcomp(response, center = TRUE, scale. = FALSE)
  retained <- response_pca$sdev > max(response_pca$sdev) * 1e-10
  compact_response <- response_pca$x[, retained, drop = FALSE]
  geometry_rows[[s]] <- tibble(scope = scope$scope, original_columns = ncol(response),
    retained_axes = sum(retained),
    max_distance_error = max(abs(as.matrix(dist(response)) - as.matrix(dist(compact_response)))))
  response <- compact_response
  class_pca <- prcomp(class_values, center = TRUE, scale. = FALSE)
  class_rank <- sum(class_pca$sdev > max(class_pca$sdev) * 1e-8)
  class_names <- paste0("class_pc", seq_len(class_rank))
  for (k in seq_along(class_names)) d[[class_names[k]]] <- class_pca$x[, k]
  class_conditions <- paste(class_names, collapse = " + ")
  seed <- profile_seed + s
  set.seed(seed)
  permutations <- shuffleSet(nrow(d), nset = n_permutations)
  for (j in seq_len(nrow(profile_design))) {
    design <- profile_design[j, ]
    other_conditions <- sub("CLASS", class_conditions, design$other_conditions, fixed = TRUE)
    for (a in seq_len(nrow(adjustment_design))) {
      adjustment <- adjustment_design[a, ]
      components <- c(adjustment$profile_detection, other_conditions)
      conditions <- paste(components[nzchar(components)], collapse = " + ")
      rhs <- design$tested
      if (nzchar(conditions)) rhs <- paste0(rhs, " + Condition(", conditions, ")")
      fit <- rda(as.formula(paste("response ~", rhs)), data = d)
      test <- anova(fit, permutations = permutations, model = "reduced")
      profile_rows[[length(profile_rows) + 1]] <- bind_cols(scope, design,
        tibble(adjustment = adjustment$adjustment, conditions, seed, units = nrow(d),
          unique_fraction = fit$CCA$tot.chi / fit$tot.chi,
          adjusted_unique_fraction = RsquareAdj(fit)$adj.r.squared,
          pseudo_f = test$F[1], p_value = test$`Pr(>F)`[1]))
      if (scope$scope == "all_35_segments" & adjustment$adjustment == "without_detection") {
        for (k in seq_len(nrow(d))) {
          reduced_response <- response[-k, , drop = FALSE]
          reduced_fit <- rda(as.formula(paste("reduced_response ~", rhs)), data = d[-k, ])
          profile_deletions[[length(profile_deletions) + 1]] <- tibble(model = design$model,
            removed_segment = d$site_segment_number[k],
            unique_fraction = reduced_fit$CCA$tot.chi / reduced_fit$tot.chi,
            adjusted_unique_fraction = RsquareAdj(reduced_fit)$adj.r.squared)
        }
      }
    }
  }
}
profile_tests <- bind_rows(profile_rows) %>% group_by(scope, adjustment) %>%
  mutate(p_bh = p.adjust(p_value, "BH"), family_size = n()) %>% ungroup()
write_csv(profile_tests, file.path(results_dir, "whole_profile_tests.csv"))
write_csv(bind_rows(profile_audit), file.path(results_dir, "profile_inclusion_audit.csv"))
write_csv(bind_rows(profile_deletions), file.path(results_dir, "profile_leave_one_segment_out.csv"))
geometry_checks <- bind_rows(geometry_rows)
write_csv(geometry_checks, file.path(results_dir, "profile_geometry_checks.csv"))
profile_reproduction <- profile_tests %>%
  filter(adjustment == "with_detection", !is.na(previous_model)) %>%
  left_join(previous_profiles %>% select(scope, previous_model = model,
    previous_p = p_value, previous_fraction = unique_fraction), by = c("scope", "previous_model"))

# 5. Draw the six targeted associations without detection conditioning ----------
primary <- target_tests %>% filter(role == "primary", adjustment == "without_detection")
residuals <- bind_rows(plot_residuals)
x_limits <- range(residuals$enzyme_residual)
y_limits <- range(residuals$motif_residual)
plots <- list()
for (j in seq_len(nrow(target_design))) {
  design <- target_design[j, ]
  d <- plot_residuals[[design$comparison]]
  d$panel <- paste0(design$enzyme, ": ", design$motif)
  result <- primary %>% filter(comparison == design$comparison)
  p <- ggplot(d, aes(enzyme_residual, motif_residual, color = network_group)) +
    geom_hline(yintercept = 0, color = "#D9D9D9", linewidth = 0.3) +
    geom_vline(xintercept = 0, color = "#D9D9D9", linewidth = 0.3) +
    geom_point(size = 2.2, alpha = 0.85) +
    scale_color_manual(values = group_colors, name = NULL) +
    coord_cartesian(xlim = x_limits, ylim = y_limits) +
    facet_wrap(~panel) + labs(x = "Enzyme activity (adjusted, SD)",
      y = "Compatible-pair fraction (adjusted, SD)") + plot_theme
  if (result$p_bh < significance_threshold) {
    p <- p + geom_abline(intercept = 0, slope = result$partial_r,
      color = "black", linewidth = 0.5)
  }
  plots[[j]] <- p
  ggsave(file.path(figures_dir, paste0("2016_no_detection_", design$comparison, ".pdf")),
    p, width = 5.1, height = 4.5, bg = "white")
}
combined <- wrap_plots(plots, ncol = 3, guides = "collect") & theme(legend.position = "bottom")
ggsave(file.path(figures_dir, "2016_targeted_enzymes_without_detection.pdf"),
  combined, width = 15.3, height = 8.5, bg = "white")
effect_plot <- target_tests %>% filter(role == "primary") %>%
  mutate(comparison = factor(comparison, levels = rev(target_design$comparison)),
    adjustment = factor(adjustment, levels = adjustment_design$adjustment,
      labels = c("Without detection terms", "With detection terms")))
effect_labels <- setNames(paste0(target_design$enzyme, ": ", target_design$motif),
  target_design$comparison)
effect_figure <- ggplot(effect_plot,
  aes(standardized_slope, comparison, color = adjustment, group = adjustment)) +
  geom_vline(xintercept = 0, color = "#999999", linewidth = 0.4) +
  geom_linerange(aes(xmin = standardized_lower_95, xmax = standardized_upper_95),
    position = position_dodge(width = 0.5), orientation = "y", linewidth = 0.6) +
  geom_point(aes(shape = p_bh < significance_threshold),
    position = position_dodge(width = 0.5), size = 2.5) +
  scale_shape_manual(values = c(`FALSE` = 1, `TRUE` = 16),
    labels = c(`FALSE` = "BH P >= 0.05", `TRUE` = "BH P < 0.05"), name = NULL) +
  scale_color_manual(values = c("Without detection terms" = "#0072B2",
    "With detection terms" = "#E69F00"), name = NULL) +
  scale_y_discrete(labels = effect_labels) +
  labs(x = "Standardized enzyme slope (95% model interval)", y = NULL) + plot_theme +
  guides(color = guide_legend(nrow = 1), shape = guide_legend(nrow = 1))
ggsave(file.path(figures_dir, "2016_targeted_detection_comparison.pdf"),
  effect_figure, width = 10.5, height = 5.5, bg = "white")
profile_labels <- c(network = "River position",
  network_beyond_classes = "River position | molecular classes",
  enzymes = "Enzyme profile", enzymes_beyond_classes = "Enzyme profile | position + classes")
profile_plot_data <- profile_tests %>% filter(scope == "all_35_segments") %>%
  mutate(model = factor(model, levels = rev(profile_design$model)),
    adjustment = factor(adjustment, levels = adjustment_design$adjustment,
      labels = c("Without detection terms", "With detection terms")))
profile_figure <- ggplot(profile_plot_data,
  aes(100 * unique_fraction, model, color = adjustment, group = adjustment)) +
  geom_point(aes(shape = p_bh < significance_threshold),
    position = position_dodge(width = 0.45), size = 3) +
  scale_y_discrete(labels = profile_labels) +
  scale_color_manual(values = c("Without detection terms" = "#0072B2",
    "With detection terms" = "#E69F00"), name = NULL) +
  scale_shape_manual(values = c(`FALSE` = 1, `TRUE` = 16),
    labels = c(`FALSE` = "BH P >= 0.05", `TRUE` = "BH P < 0.05"), name = NULL) +
  labs(x = "Unique transformation variation (%)", y = NULL) + plot_theme +
  guides(color = guide_legend(nrow = 1), shape = guide_legend(nrow = 1))
ggsave(file.path(figures_dir, "2016_whole_profile_detection_comparison.pdf"),
  profile_figure, width = 9.5, height = 4.2, bg = "white")

# 6. Display the observed PCA colored by each potential enzyme ------------------
# This PCA was never residualized; values reproduce the observed view in 16.
# Color is asinh-scaled potential activity to retain zeros and show its gradient.
enzyme_plots <- list()
for (enzyme in c("glu", "lap", "nag", "ap")) {
  d <- scores
  d$enzyme_activity <- d[[enzyme]]
  p <- ggplot(d, aes(PC1, PC2, color = enzyme_activity)) +
    geom_point(size = 2.7, alpha = 0.85) + coord_equal() +
    scale_color_viridis_c(name = paste0(toupper(enzyme), " potential activity\n(asinh scaled)")) +
    labs(x = sprintf("Observed PC1 (%.1f%%)", variance$percent_within_view[1]),
      y = sprintf("Observed PC2 (%.1f%%)", variance$percent_within_view[2])) + plot_theme
  enzyme_plots[[enzyme]] <- p
  ggsave(file.path(figures_dir, paste0("2016_observed_pca_", enzyme, ".pdf")),
    p, width = 6.2, height = 4.5, bg = "white")
}
ggsave(file.path(figures_dir, "2016_observed_pca_enzyme_gradients.pdf"),
  wrap_plots(enzyme_plots, ncol = 2), width = 12.4, height = 9, bg = "white")

# 7. Validate against the original fits and direct OLS permutation refits --------
d <- primary_units[[target_design$comparison[1]]]
set.seed(target_seed)
validation_permutations <- shuffleSet(nrow(d), nset = 99L)
optimized <- fit_target(d, "log_area + log_organic", validation_permutations)
reduced <- lm(response ~ log_area + log_organic, data = d)
direct_t <- numeric(nrow(validation_permutations))
for (i in seq_len(nrow(validation_permutations))) {
  d$permuted <- fitted(reduced) + resid(reduced)[validation_permutations[i, ]]
  direct <- lm(permuted ~ log_area + log_organic + enzyme_transformed, data = d)
  direct_t[i] <- coef(summary(direct))["enzyme_transformed", "t value"]
}
integrity <- tibble(path = substring(input_paths, nchar(here()) + 2L),
  md5_before = input_md5, md5_after = unname(tools::md5sum(input_paths))) %>%
  mutate(unchanged = md5_before == md5_after)
validation <- tibble(check = c("all_prior_target_fits_reproduced", "prior_profile_fits_reproduced",
  "profile_geometry_preserved", "direct_permutation_refits_agree", "declared_test_families", "source_inputs_unchanged"),
  passed = c(nrow(target_reproduction) == 24 & !anyNA(target_reproduction$previous_p) &
    max(abs(target_reproduction$partial_r - target_reproduction$previous_r)) < 1e-9 &
    max(abs(target_reproduction$slope - target_reproduction$previous_slope)) < 1e-9 &
    max(abs(target_reproduction$p_value - target_reproduction$previous_p)) < 1e-12 &
    max(abs(target_reproduction$p_bh - target_reproduction$previous_q)) < 1e-12,
    nrow(profile_reproduction) == 12 & !anyNA(profile_reproduction$previous_p) &
      max(abs(profile_reproduction$unique_fraction - profile_reproduction$previous_fraction)) < 1e-9 &
      all(profile_reproduction$p_value == profile_reproduction$previous_p),
    all(geometry_checks$max_distance_error < 1e-10),
    max(abs(direct_t - optimized$permutation_t)) < 1e-8,
    all(target_tests$family_size == 6) & all(profile_tests$family_size == 4),
    all(integrity$unchanged)))
write_csv(integrity, file.path(results_dir, "input_integrity.csv"))
write_csv(validation, file.path(results_dir, "numerical_validation.csv"))
writeLines(capture.output(sessionInfo()), file.path(results_dir, "session_info.txt"))
stopifnot(all(validation$passed))
history_path <- file.path(results_dir, "run_history.csv")
if (file.exists(history_path)) {
  history <- read_csv(history_path, show_col_types = FALSE)
  history <- bind_rows(history, tibble(attempt = max(history$attempt) + 1,
    status = "complete", last_completed_stage = "all_validation_checks",
    note = "All nonzero PCA coordinates preserve original profile distances and reproduce prior fits"))
  write_csv(history, history_path)
}
message("Without detection terms: ", sum(primary$p_bh < significance_threshold),
  " of six targeted segment-level associations pass BH correction.")
