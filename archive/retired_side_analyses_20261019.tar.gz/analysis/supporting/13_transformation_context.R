# River-position changes and chemical neighborhoods of the mapped association group.

library(here)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(vegan)
library(permute)

# 1. Settings and explicit comparisons ------------------------------------------
results_dir <- here("results", "fticr_2016", "transformation_context")
figures_dir <- here("figures", "supplement", "transformation_context")
transformation_dir <- here("results", "fticr_2016", "transformations")
n_permutations <- 9999L
n_equal_feature_draws <- 200L
n_null_draws <- 4999L
permutation_seed <- 202610180L
null_seed <- 202610181L
core_id <- 2L
common_label_count <- 12L
mass_tolerance <- 0.000010
null_mass_caliper <- 50
null_prevalence_caliper <- 2L
null_h_c_caliper <- 0.3
null_o_c_caliper <- 0.15
group_levels <- c("Headwater", "Intermediate", "Mainstem")
group_colors <- c(Headwater = "#009E73", Intermediate = "#E69F00", Mainstem = "#0072B2")
model_design <- tribble(
  ~model, ~tested, ~conditions, ~role,
  "network_raw", "network_group", "", "diagnostic",
  "network_detection", "network_group", "log_detection + I(log_detection^2)", "primary",
  "network_broad_classes", "network_group", "log_detection + I(log_detection^2) + CLASS", "primary",
  "enzyme_beyond_classes", "enzyme_pc1 + enzyme_pc2",
  "log_detection + I(log_detection^2) + network_group + CLASS", "primary"
)
# Formulas describe net additions from lower to higher measured m/z, not fluxes.
motif_design <- tribble(
  ~motif, ~reference_label, ~C, ~H, ~O, ~N, ~S, ~P, ~Na,
  "H2", "hydrogenation/dehydrogenation", 0, 2, 0, 0, 0, 0, 0,
  "O", "hydroxylation (-H)", 0, 0, 1, 0, 0, 0, 0,
  "H2O", "condensation/dehydration", 0, 2, 1, 0, 0, 0, 0,
  "CO2", "Carboxylation", 1, 0, 2, 0, 0, 0, 0,
  "CH2", "methanol (-H2O)", 1, 2, 0, 0, 0, 0, 0,
  "NH2", "primary amine", 0, 2, 0, 1, 0, 0, 0,
  "HPO3", "phosphate", 0, 1, 3, 0, 0, 1, 0,
  "SO3", "sulfate (-H2O)", 0, 0, 3, 0, 1, 0, 0,
  "C6H10O5", "C6H10O5", 6, 10, 5, 0, 0, 0, 0,
  "C2H2O", "acetylation (-H2O)", 2, 2, 1, 0, 0, 0, 0,
  "Glycine residue", "Glycine", 2, 3, 1, 1, 0, 0, 0,
  "Valine residue", "Valine", 5, 9, 1, 1, 0, 0, 0
)
plot_theme <- theme_bw(base_size = 12) +
  theme(panel.grid = element_blank(), strip.background = element_blank())

# 2. Align source inputs, the full sediment pool, and the Figure 3 intersection ---
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)
input_paths <- c(
  file.path(transformation_dir, "transformation_profiles.csv"),
  file.path(transformation_dir, "peak_pair_assignments.csv.gz"),
  file.path(transformation_dir, "site_summary.csv"),
  here("data", "derived", "fticr_2016", "sediment_44_presence_absence.csv"),
  here("results", "fticr_2016", "tables", "primary_peak_properties.csv"),
  here("results", "fticr_2016", "river_composition", "site_class_fractions.csv"),
  here("data", "derived", "sediment_characteristics_2016", "response_pool_model_inputs.csv"),
  here("results", "fticr_2016", "bipartite_networks", "stable_core_molecular_properties.csv"),
  here("results", "fticr_2016", "bipartite_networks", "feature_inclusion_audit.csv"),
  here("results", "fticr_2016", "stable_group_distribution", "core_site_profiles.csv"),
  here("results", "fticr_2016", "matched_sediment_dispersion", "matched_site_manifest.csv"),
  here("results", "fticr_2016", "river_composition", "subsampling_design.csv"),
  here("reference", "danczak_2020", "Transformation_Database_07-2020.csv"),
  here("results", "fticr_2016", "matched_sediment_dispersion", "balanced_site_selection.csv")
)
input_md5 <- unname(tools::md5sum(input_paths))
stopifnot(!anyNA(input_md5))
profile_table <- read_csv(input_paths[1], show_col_types = FALSE)
pairs <- read_csv(input_paths[2], show_col_types = FALSE) %>% filter(published_assignment)
site <- read_csv(input_paths[3], col_types = cols(site_code = col_character())) %>%
  mutate(network_group = factor(case_when(site_stream_order <= 2 ~ "Headwater",
    site_stream_order <= 4 ~ "Intermediate", site_stream_order == 5 ~ "Mainstem"),
    levels = group_levels), log_detection = log10(detected_features))
pa_table <- read_csv(input_paths[4], col_types = cols(site_code = col_character()))
peaks <- read_csv(input_paths[5], show_col_types = FALSE)
class_table <- read_csv(input_paths[6], col_types = cols(site_code = col_character()))
enzyme_models <- read_csv(input_paths[7], col_types = cols(site_code = col_character())) %>%
  filter(pool == "molecular")
core <- read_csv(input_paths[8], show_col_types = FALSE) %>% filter(core == core_id)
eligibility <- read_csv(input_paths[9], show_col_types = FALSE) %>%
  filter(node_type == "Molecular", included)
core_site <- read_csv(input_paths[10], col_types = cols(site_code = col_character()))
matched_manifest <- read_csv(input_paths[11], col_types = cols(site_code = col_character()))
draw_design <- read_csv(input_paths[12], show_col_types = FALSE) %>%
  slice_head(n = n_equal_feature_draws)
reference <- read_csv(input_paths[13], show_col_types = FALSE)
balanced_selections <- read_csv(input_paths[14], col_types = cols(site_code = col_character()))
site <- site %>% left_join(select(enzyme_models, site_code, enzyme_pc1, enzyme_pc2),
  by = "site_code") %>%
  mutate(matched_33 = site_code %in% matched_manifest$site_code)
pa <- as.matrix(pa_table[, -1])
rownames(pa) <- pa_table$site_code
profiles <- t(as.matrix(profile_table[, site$site_code]))
colnames(profiles) <- profile_table$transformation
classes <- class_table %>% select(site_code, source_class, fraction_detected) %>%
  pivot_wider(names_from = source_class, values_from = fraction_detected)
class_matrix <- as.matrix(classes[match(site$site_code, classes$site_code), -1])
stopifnot(nrow(site) == 44, sum(site$matched_33) == 33,
  nrow(core) == 8, !anyNA(site),
  identical(site$site_code, rownames(profiles)),
  identical(site$site_code, rownames(pa)), identical(peaks$peak_id, colnames(pa)),
  all(rowSums(profiles) == site$matched_peak_pairs),
  all(rowSums(pa) == site$detected_features),
  all(abs(rowSums(class_matrix) - 1) < 1e-12))
write_csv(select(site, site_code, network_group, site_segment_number, matched_33,
  detected_features), file.path(results_dir, "site_inclusion_audit.csv"))

# 3. Check formula-compatible motifs without changing the published profiles ----
element_columns <- c(C = "carbon_count", H = "hydrogen_count", O = "oxygen_count",
  N = "nitrogen_count", S = "sulfur_count", P = "phosphorus_count", Na = "sodium_count")
lower <- match(pairs$lower_peak_id, peaks$peak_id)
upper <- match(pairs$upper_peak_id, peaks$peak_id)
stopifnot(!anyNA(lower), !anyNA(upper))
delta <- as.matrix(peaks[upper, element_columns]) -
  as.matrix(peaks[lower, element_columns])
colnames(delta) <- names(element_columns)
co_detected <- pa[, lower, drop = FALSE] > 0 & pa[, upper, drop = FALSE] > 0
stopifnot(all(colSums(co_detected) == pairs$observed_sites))
motif_design$mass <- reference$Mass[match(motif_design$reference_label, reference$Name)]
stopifnot(!anyNA(motif_design$mass))
motif_match <- matrix(FALSE, nrow(pairs), nrow(motif_design),
  dimnames = list(pairs$pair_id, motif_design$motif))
motif_audit <- vector("list", nrow(motif_design))
for (j in seq_len(nrow(motif_design))) {
  mass_match <- pairs$observed_difference + mass_tolerance >= motif_design$mass[j] &
    pairs$observed_difference - mass_tolerance <= motif_design$mass[j]
  formula_match <- rowSums(sweep(delta, 2,
    as.numeric(motif_design[j, names(element_columns)]), "!=") != 0) == 0
  motif_match[, j] <- mass_match & formula_match
  motif_audit[[j]] <- motif_design[j, ] %>% mutate(
    mass_matched_pairs = sum(mass_match), compatible_pairs = sum(mass_match & formula_match),
    compatible_single_candidate_pairs = sum(mass_match & formula_match &
      peaks$candidate_count[lower] == 1 & peaks$candidate_count[upper] == 1))
}
write_csv(bind_rows(motif_audit), file.path(results_dir, "motif_formula_audit.csv"))
motif_profiles <- co_detected %*% (1L * motif_match)
motif_long <- bind_cols(select(site, site_code, network_group), as_tibble(motif_profiles)) %>%
  pivot_longer(-c(site_code, network_group), names_to = "motif", values_to = "pairs") %>%
  left_join(select(site, site_code, matched_peak_pairs), by = "site_code") %>%
  mutate(fraction_all_matches = pairs / matched_peak_pairs)
write_csv(motif_long, file.path(results_dir, "site_formula_compatible_motifs.csv"))

# 4. Use the same observed-feature draws as the Figure 3 source analysis ---------
# This is a sensitivity to detected feature count, not recovery of missing ions.
target_features <- min(rowSums(pa))
equal_profiles <- matrix(0, nrow(profiles), ncol(profiles), dimnames = dimnames(profiles))
equal_distance <- matrix(0, nrow(profiles), nrow(profiles),
  dimnames = list(rownames(profiles), rownames(profiles)))
variance_design <- expand_grid(pool = c("all", "matched"), network_group = group_levels)
variance_indices <- vector("list", nrow(variance_design))
for (j in seq_len(nrow(variance_design))) {
  included <- as.character(site$network_group) == variance_design$network_group[j]
  if (variance_design$pool[j] == "matched") included <- included & site$matched_33
  variance_indices[[j]] <- which(included)
}
mean_draw_variance <- numeric(nrow(variance_design))
draw_design$completed <- FALSE
draw_design$error_message <- NA_character_
draw_design$elapsed_seconds <- NA_real_
for (run in seq_len(nrow(draw_design))) {
  started <- proc.time()[["elapsed"]]
  set.seed(draw_design$seed[run])
  result <- tryCatch({
    selected <- matrix(FALSE, nrow(pa), ncol(pa))
    for (i in seq_len(nrow(pa))) {
      indices <- sample(which(pa[i, ] > 0), target_features, replace = FALSE)
      selected[i, indices] <- TRUE
    }
    stopifnot(all(rowSums(selected) == target_features))
    run_profiles <- matrix(0L, nrow(profiles), ncol(profiles))
    for (i in seq_len(nrow(pa))) {
      kept <- selected[i, lower] & selected[i, upper]
      run_profiles[i, ] <- tabulate(pairs$database_row[kept], nbins = ncol(profiles))
    }
    stopifnot(all(rowSums(run_profiles) > 0))
    sqrt(run_profiles / rowSums(run_profiles))
  }, error = function(e) e)
  if (inherits(result, "error")) {
    draw_design$error_message[run] <- conditionMessage(result)
  } else {
    equal_profiles <- equal_profiles + result
    equal_distance <- equal_distance + as.matrix(dist(result))
    for (j in seq_along(variance_indices)) {
      indices <- variance_indices[[j]]
      n <- length(indices)
      # Each draw has unit Hellinger norm; this is squared scatter around the centroid.
      scatter <- n - n * sum(colMeans(result[indices, , drop = FALSE])^2)
      mean_draw_variance[j] <- mean_draw_variance[j] + scatter / (n - 1)
    }
    draw_design$completed[run] <- TRUE
  }
  draw_design$elapsed_seconds[run] <- proc.time()[["elapsed"]] - started
  if (run == 1) message("First equal-feature transformation draw: ",
    round(draw_design$elapsed_seconds[run], 3), " seconds.")
}
write_csv(draw_design, file.path(results_dir, "equal_feature_draws.csv"))
stopifnot(all(draw_design$completed))
equal_profiles <- equal_profiles / sum(draw_design$completed)
equal_distance <- equal_distance / sum(draw_design$completed)
mean_draw_variance <- mean_draw_variance / sum(draw_design$completed)
mean_profile_variance <- numeric(nrow(variance_design))
for (j in seq_along(variance_indices)) {
  values <- equal_profiles[variance_indices[[j]], , drop = FALSE]
  centered <- sweep(values, 2, colMeans(values), "-")
  mean_profile_variance[j] <- sum(centered^2) / (nrow(values) - 1)
}
variance_decomposition <- variance_design %>%
  mutate(mean_draw_variance = mean_draw_variance,
    mean_profile_variance = mean_profile_variance,
    thinning_component = mean_draw_variance - mean_profile_variance,
    thinning_fraction = thinning_component / mean_draw_variance)
stopifnot(all(variance_decomposition$thinning_component > -1e-12))
write_csv(variance_decomposition, file.path(results_dir, "thinning_variance_decomposition.csv"))
write_csv(bind_cols(tibble(site_code = site$site_code), as_tibble(equal_profiles)),
  file.path(results_dir, "equal_feature_mean_hellinger.csv.gz"))
write_csv(bind_cols(tibble(site_code = site$site_code), as_tibble(equal_distance)),
  file.path(results_dir, "equal_feature_mean_distance.csv"))

# 5. Ask what changes beyond detection, broad classes, and potential enzymes -----
# Null: the tested block adds no association conditional on the named predictors.
# Segment-centroid tests give each segment one unit and permute entire centroids.
# They do not preserve river-network autocorrelation or establish downstream change.
fit_profile <- function(response, model_data, tested, conditions, permutations = 0) {
  rhs <- tested
  if (nzchar(conditions)) rhs <- paste0(rhs, " + Condition(", conditions, ")")
  fit <- rda(as.formula(paste("response ~", rhs)), data = model_data)
  result <- tibble(units = nrow(model_data), constrained_rank = fit$CCA$rank,
    residual_rank = fit$CA$rank, unique_fraction = fit$CCA$tot.chi / fit$tot.chi,
    adjusted_unique_fraction = RsquareAdj(fit)$adj.r.squared)
  if (is.matrix(permutations)) {
    test <- anova(fit, permutations = permutations, model = "reduced")
    result$pseudo_f <- test$F[1]
    result$p_value <- test$`Pr(>F)`[1]
    result$diagnostic <- if_else(fit$CCA$rank == 0,
      "no_added_constrained_rank", "estimated")
  }
  result
}
hellinger <- sqrt(profiles / rowSums(profiles))
test_rows <- list()
removal_rows <- list()
common_rows <- list()
common_labels <- names(sort(colMeans(profiles / rowSums(profiles)),
  decreasing = TRUE))[seq_len(common_label_count)]
scope_design <- tribble(
  ~scope, ~pool, ~unit,
  "all_44_sites", "all", "site",
  "all_35_segments", "all", "segment",
  "matched_33_sites", "matched", "site",
  "matched_segments", "matched", "segment",
  "equal_feature_segments", "equal", "segment"
)
for (s in seq_len(nrow(scope_design))) {
  current <- scope_design[s, ]
  included <- rep(TRUE, nrow(site))
  if (current$pool == "matched") included <- site$matched_33
  model_data <- site[included, ]
  response <- hellinger[included, , drop = FALSE]
  if (current$pool == "equal") response <- equal_profiles
  class_values <- class_matrix[included, , drop = FALSE]
  if (current$unit == "segment") {
    segment <- factor(model_data$site_segment_number)
    index <- split(seq_len(nrow(model_data)), segment)
    stopifnot(all(vapply(index, function(i)
      n_distinct(model_data$network_group[i]) == 1, logical(1))))
    aggregate_matrix <- matrix(0, length(index), ncol(response))
    aggregate_classes <- matrix(0, length(index), ncol(class_values))
    aggregate_rows <- vector("list", length(index))
    for (k in seq_along(index)) {
      i <- index[[k]]
      aggregate_matrix[k, ] <- colMeans(response[i, , drop = FALSE])
      aggregate_classes[k, ] <- colMeans(class_values[i, , drop = FALSE])
      aggregate_rows[[k]] <- model_data[i[1], ] %>% mutate(
        log_detection = mean(model_data$log_detection[i]),
        enzyme_pc1 = mean(model_data$enzyme_pc1[i]),
        enzyme_pc2 = mean(model_data$enzyme_pc2[i]))
    }
    model_data <- bind_rows(aggregate_rows)
    response <- aggregate_matrix
    class_values <- aggregate_classes
  }
  class_pca <- prcomp(class_values, center = TRUE, scale. = FALSE)
  class_rank <- sum(class_pca$sdev > max(class_pca$sdev) * 1e-8)
  class_names <- paste0("class_pc", seq_len(class_rank))
  for (j in seq_along(class_names)) model_data[[class_names[j]]] <- class_pca$x[, j]
  class_conditions <- paste(class_names, collapse = " + ")
  set.seed(permutation_seed + s)
  permutations <- shuffleSet(nrow(model_data), nset = n_permutations)
  for (j in seq_len(nrow(model_design))) {
    design <- model_design[j, ]
    conditions <- sub("CLASS", class_conditions, design$conditions, fixed = TRUE)
    result <- fit_profile(response, model_data, design$tested, conditions, permutations)
    test_rows[[length(test_rows) + 1L]] <- bind_cols(current, design, result) %>%
      mutate(conditions = conditions, class_covariates = class_rank,
        seed = permutation_seed + s)
    if (current$scope == "all_35_segments" & design$role == "primary") {
      for (k in seq_len(nrow(model_data))) {
        reduced <- fit_profile(response[-k, , drop = FALSE], model_data[-k, ],
          design$tested, conditions)
        removal_rows[[length(removal_rows) + 1L]] <- reduced %>%
          mutate(model = design$model, omitted_segment = model_data$site_segment_number[k])
      }
    }
  }
  if (current$scope == "all_35_segments") {
    # Label selection uses overall abundance, without using network-group contrasts.
    label_response <- sqrt(profiles / rowSums(profiles))
    for (label in common_labels) {
      values <- vapply(index, function(i) mean(label_response[i, label]), numeric(1))
      result <- fit_profile(matrix(values, ncol = 1), model_data, "network_group",
        "log_detection + I(log_detection^2)", permutations)
      common_rows[[label]] <- mutate(result, transformation = label)
    }
  }
  message("Completed conditional profile models: ", current$scope)
}
tests <- bind_rows(test_rows) %>% group_by(scope, role) %>%
  mutate(p_bh = p.adjust(p_value, "BH")) %>% ungroup()
write_csv(tests, file.path(results_dir, "conditional_profile_tests.csv"))
write_csv(bind_rows(removal_rows), file.path(results_dir, "leave_one_segment_out.csv"))
common_tests <- bind_rows(common_rows) %>%
  mutate(p_for_bh = if_else(constrained_rank == 0, 1, p_value),
    p_bh = p.adjust(p_for_bh, "BH", n = common_label_count))
write_csv(common_tests, file.path(results_dir, "common_label_tests.csv"))

# Match Figure 3's site identities and segment-balanced selections for dispersion.
distance_views <- list(complete = as.matrix(dist(hellinger)), equal_features = equal_distance)
dispersion_rows <- list()
dispersion_tests <- list()
dispersion_contrasts <- list()
balanced_rows <- list()
for (pool in c("all", "matched")) {
  included <- rep(TRUE, nrow(site))
  if (pool == "matched") included <- site$matched_33
  display_sites <- site[included, ]
  set.seed(permutation_seed + 100)
  permutations <- shuffleSet(nrow(display_sites), nset = n_permutations)
  for (view in names(distance_views)) {
    distance_matrix <- distance_views[[view]][included, included]
    geometry <- wcmdscale(as.dist(distance_matrix), eig = TRUE, add = "lingoes")
    correction <- geometry$ac
    corrected <- sqrt(distance_matrix^2 + 2 * correction)
    diag(corrected) <- 0
    fit <- betadisper(as.dist(corrected), display_sites$network_group,
      type = "median", bias.adjust = TRUE)
    test <- permutest(fit, permutations = permutations, pairwise = TRUE)
    means <- tapply(fit$distances, display_sites$network_group, mean)
    dispersion_rows[[length(dispersion_rows) + 1L]] <- display_sites %>%
      select(site_code, network_group) %>% mutate(pool, view, distance = fit$distances)
    dispersion_tests[[length(dispersion_tests) + 1L]] <- tibble(pool, view,
      sites = nrow(display_sites), headwater_mean = means["Headwater"],
      intermediate_mean = means["Intermediate"], mainstem_mean = means["Mainstem"],
      headwater_mainstem_ratio = means["Headwater"] / means["Mainstem"],
      p_value = test$tab[1, "Pr(>F)"], lingoes_constant = correction)
    for (contrast in names(test$pairwise$permuted)) {
      dispersion_contrasts[[length(dispersion_contrasts) + 1L]] <- tibble(pool, view,
        contrast, p_value = test$pairwise$permuted[contrast])
    }
    if (pool != "matched") next
    for (run in sort(unique(balanced_selections$run))) {
      selected_sites <- balanced_selections %>% filter(.data$run == .env$run)
      i <- match(selected_sites$site_code, display_sites$site_code)
      stopifnot(!anyNA(i),
        all(as.character(display_sites$network_group[i]) == selected_sites$network_group))
      current_fit <- betadisper(as.dist(corrected[i, i]), selected_sites$network_group,
        type = "median", bias.adjust = TRUE)
      current_means <- tapply(current_fit$distances, selected_sites$network_group, mean)
      balanced_rows[[length(balanced_rows) + 1L]] <- tibble(run, view,
        headwater_mainstem_ratio = current_means["Headwater"] / current_means["Mainstem"],
        intermediate_mainstem_ratio = current_means["Intermediate"] / current_means["Mainstem"])
    }
  }
}
dispersion <- bind_rows(dispersion_rows)
dispersion_test_table <- bind_rows(dispersion_tests) %>% group_by(pool) %>%
  mutate(p_bh = p.adjust(p_value, "BH")) %>% ungroup()
write_csv(dispersion, file.path(results_dir, "profile_dispersion_by_site.csv"))
write_csv(dispersion_test_table, file.path(results_dir, "profile_dispersion_tests.csv"))
write_csv(bind_rows(dispersion_contrasts) %>% group_by(pool) %>%
  mutate(p_bh = p.adjust(p_value, "BH")) %>% ungroup(),
  file.path(results_dir, "profile_dispersion_contrasts.csv"))
write_csv(bind_rows(balanced_rows), file.path(results_dir, "profile_dispersion_balanced_draws.csv"))

# 6. Describe the chemical neighborhood of the eight Fig. 4 molecules -----------
paired_occurrences <- colSums(co_detected[site$matched_33, , drop = FALSE])
core_lower <- pairs$lower_peak_id %in% core$feature_id
core_upper <- pairs$upper_peak_id %in% core$feature_id
neighborhood <- pairs %>% mutate(
  lower_in_core = core_lower, upper_in_core = core_upper,
  occurrences_33 = paired_occurrences,
  lower_candidate_count = peaks$candidate_count[lower],
  upper_candidate_count = peaks$candidate_count[upper]
) %>% bind_cols(as_tibble(delta, .name_repair = "minimal")) %>%
  filter((lower_in_core | upper_in_core) & occurrences_33 > 0)
write_csv(neighborhood, file.path(results_dir, "core_chemical_neighborhood.csv.gz"))
category_match <- cbind(motif_match, N_changing = delta[, "N"] != 0,
  S_changing = delta[, "S"] != 0)
peak_events <- matrix(0, nrow(peaks), ncol(category_match) + 1,
  dimnames = list(peaks$peak_id, c("all_connections", colnames(category_match))))
for (j in seq_len(ncol(peak_events))) {
  weights <- paired_occurrences
  if (j > 1) weights <- weights * category_match[, j - 1]
  # Each connection contributes one endpoint to each feature; internal edges
  # contribute two endpoints when summarizing a feature set.
  totals <- rowsum(c(weights, weights), c(lower, upper), reorder = FALSE)
  peak_events[as.integer(rownames(totals)), j] <- totals[, 1]
}
prevalence_33 <- colSums(pa[site$matched_33, , drop = FALSE] > 0)
adjacency <- matrix(0L, nrow(peaks), nrow(peaks))
observed_edges <- paired_occurrences > 0
adjacency[cbind(lower[observed_edges], upper[observed_edges])] <- 1L
adjacency <- adjacency + t(adjacency)
core_index <- match(core$feature_id, peaks$peak_id)
feature_summary <- core %>% transmute(feature_id, candidate_count,
  measured_mz, nitrogen_count, sulfur_count,
  prevalence_33 = prevalence_33[core_index],
  mean_degree_per_detection = peak_events[core_index, "all_connections"] /
    .env$prevalence_33[core_index],
  within_core_neighbors = rowSums(adjacency[core_index, core_index, drop = FALSE]))
write_csv(feature_summary, file.path(results_dir, "core_feature_summary.csv"))

# 7. Conditional feature-set nulls for chemical annotation, not guild validation -
# Preserve eight features, similar prevalence on the same 33 sites, and similar
# mass. The chemistry sensitivity also matches N/S/P presence. Incidence data,
# chemical edges, and ASV associations are held fixed; core membership is randomized.
# Selection of the original association group is not repeated by these nulls.
background <- peaks %>% inner_join(select(eligibility, feature_id, present),
  by = c("peak_id" = "feature_id")) %>% filter(!peak_id %in% core$feature_id)
candidate_rows <- list()
for (scheme in c("prevalence_mass", "prevalence_mass_elements")) {
  for (i in seq_len(nrow(core))) {
    target <- core[i, ]
    candidates <- background %>% filter(
      abs(present - prevalence_33[core_index[i]]) <= null_prevalence_caliper,
      abs(measured_mz - target$measured_mz) <= null_mass_caliper)
    if (scheme == "prevalence_mass_elements") {
      candidates <- candidates %>% filter(
        (nitrogen_count > 0) == (target$nitrogen_count > 0),
        (sulfur_count > 0) == (target$sulfur_count > 0),
        (phosphorus_count > 0) == (target$phosphorus_count > 0))
    }
    stopifnot(nrow(candidates) >= 2)
    candidate_rows[[length(candidate_rows) + 1L]] <- tibble(scheme,
      target_feature = target$feature_id, candidate_feature = candidates$peak_id)
  }
}
candidates <- bind_rows(candidate_rows)
write_csv(candidates, file.path(results_dir, "core_null_candidate_pools.csv"))
summarize_set <- function(indices) {
  events <- colSums(peak_events[indices, , drop = FALSE])
  c(mean_degree_per_detection = unname(events[1]) / sum(prevalence_33[indices]),
    within_set_pairs = sum(adjacency[indices, indices, drop = FALSE]) / 2,
    setNames(events[-1] / events[1], paste0(names(events)[-1], "_fraction")))
}
observed <- summarize_set(core_index)
null_rows <- list()
selection_rows <- list()
for (scheme in unique(candidates$scheme)) {
  pools <- split(candidates$candidate_feature[candidates$scheme == scheme],
    candidates$target_feature[candidates$scheme == scheme])
  for (run in seq_len(n_null_draws)) {
    seed <- null_seed + run + n_null_draws * match(scheme, unique(candidates$scheme))
    set.seed(seed)
    selected <- character()
    for (target in sample(names(pools))) {
      available <- setdiff(pools[[target]], selected)
      if (!length(available)) break
      selected <- c(selected, sample(available, 1))
    }
    succeeded <- length(selected) == nrow(core)
    values <- rep(NA_real_, length(observed))
    if (succeeded) values <- summarize_set(match(selected, peaks$peak_id))
    null_rows[[length(null_rows) + 1L]] <- tibble(scheme, run, seed, succeeded,
      metric = names(observed), value = unname(values))
    selection_rows[[length(selection_rows) + 1L]] <- tibble(scheme, run,
      selected_features = paste(selected, collapse = ";"), succeeded)
  }
}
null_runs <- bind_rows(null_rows)
write_csv(null_runs, file.path(results_dir, "core_null_runs.csv.gz"))
write_csv(bind_rows(selection_rows), file.path(results_dir, "core_null_selections.csv.gz"))
null_summary <- null_runs %>% filter(succeeded) %>% group_by(scheme, metric) %>%
  summarize(draws = n(), null_mean = mean(value),
    null_lower = quantile(value, 0.025), null_upper = quantile(value, 0.975),
    observed = observed[first(metric)],
    p_upper = (1 + sum(value >= observed)) / (n() + 1),
    p_lower = (1 + sum(value <= observed)) / (n() + 1), .groups = "drop") %>%
  mutate(p_two_sided = pmin(1, 2 * pmin(p_upper, p_lower)), selection_adjusted = FALSE) %>%
  group_by(scheme) %>% mutate(p_bh = p.adjust(p_two_sided, "BH")) %>% ungroup()
write_csv(null_summary, file.path(results_dir, "core_null_summary.csv"))

# 8. Save descriptive gradient panels and the conditional core comparison -------
common_long <- bind_cols(select(site, site_code, network_group),
  as_tibble(profiles[, common_labels, drop = FALSE] / rowSums(profiles))) %>%
  pivot_longer(-c(site_code, network_group), names_to = "transformation", values_to = "fraction")
common_summary <- common_long %>% group_by(transformation) %>%
  mutate(standardized_fraction = (fraction - mean(fraction)) / sd(fraction)) %>%
  group_by(transformation, network_group) %>%
  summarize(sites = n(), mean_fraction = mean(fraction),
    mean_standardized_fraction = mean(standardized_fraction), .groups = "drop") %>%
  mutate(transformation = factor(transformation, levels = rev(common_labels)))
write_csv(common_summary, file.path(results_dir, "common_label_group_means.csv"))
heatmap <- ggplot(common_summary, aes(network_group, transformation,
  fill = mean_standardized_fraction)) +
  geom_tile(color = "white", linewidth = 0.6) +
  geom_text(aes(label = sprintf("%.2f%%", 100 * mean_fraction)), size = 3.4) +
  scale_fill_gradient2(low = "#56B4E9", mid = "white", high = "#E69F00",
    midpoint = 0, name = "Mean shift\n(site SD)") +
  labs(x = NULL, y = NULL) + plot_theme
ggsave(file.path(figures_dir, "2016_transformation_network_common_labels.pdf"),
  heatmap, width = 8, height = 6.2, bg = "white")

ordination <- prcomp(hellinger, center = TRUE, scale. = FALSE)
percent <- 100 * ordination$sdev^2 / sum(ordination$sdev^2)
scores <- site %>% mutate(pc1 = ordination$x[, 1], pc2 = ordination$x[, 2])
ordination_plot <- ggplot(scores, aes(pc1, pc2, color = network_group)) +
  geom_point(size = 2.7, alpha = 0.8) +
  scale_color_manual(values = group_colors, name = NULL) +
  coord_equal() + labs(x = sprintf("Transformation PC1 (%.1f%%)", percent[1]),
    y = sprintf("Transformation PC2 (%.1f%%)", percent[2])) + plot_theme
ggsave(file.path(figures_dir, "2016_transformation_network_pca.pdf"),
  ordination_plot, width = 7, height = 3.8, bg = "white")

core_display <- null_summary %>% filter(scheme == "prevalence_mass_elements",
  grepl("_fraction$", metric), !metric %in% c("N_changing_fraction", "S_changing_fraction"),
  null_upper > 0) %>%
  mutate(label = sub("_fraction$", "", metric), label = factor(label, levels = rev(label)))
core_plot <- ggplot(core_display, aes(y = label)) +
  geom_linerange(aes(xmin = null_lower, xmax = null_upper), linewidth = 1, color = "#999999") +
  geom_point(aes(x = null_mean), shape = 1, size = 2.5) +
  geom_point(aes(x = observed), color = "#0072B2", size = 2.5) +
  scale_x_continuous(labels = scales::label_percent()) +
  labs(x = "Fraction of incident connection endpoints", y = NULL) + plot_theme
ggsave(file.path(figures_dir, "2016_core_transformation_matched_background.pdf"),
  core_plot, width = 7, height = 5.5, bg = "white")

for (view in names(distance_views)) {
  panel <- dispersion %>% filter(pool == "matched", .data$view == .env$view)
  p <- ggplot(panel, aes(network_group, distance, color = network_group)) +
    geom_boxplot(width = 0.55, outlier.shape = NA) +
    geom_point(position = position_jitter(width = 0.12, height = 0,
      seed = permutation_seed), alpha = 0.65, size = 2.4) +
    scale_color_manual(values = group_colors, guide = "none") +
    labs(x = NULL, y = "Transformation distance to\ngroup spatial median") + plot_theme
  ggsave(file.path(figures_dir, paste0("2016_transformation_dispersion_", view, ".pdf")),
    p, width = 5.8, height = 5.2, bg = "white")
}

# Show the specific formula-compatible H2O links as candidate chemical relationships.
water_pairs <- neighborhood %>% filter(C == 0, H == 2, O == 1, N == 0,
  S == 0, P == 0, Na == 0, abs(observed_difference - motif_design$mass[motif_design$motif == "H2O"]) <= mass_tolerance)
water_nodes <- bind_rows(
  water_pairs %>% transmute(pair = row_number(), x = 0,
    peak_id = if_else(lower_in_core, lower_peak_id, upper_peak_id), role = "Mapped group"),
  water_pairs %>% transmute(pair = row_number(), x = 1,
    peak_id = if_else(lower_in_core, upper_peak_id, lower_peak_id), role = "Other molecular feature")
)
water_nodes$formula <- ""
for (element in c("C", "H", "N", "O", "P", "S", "Na")) {
  number <- peaks[[element_columns[[element]]]][match(water_nodes$peak_id, peaks$peak_id)]
  water_nodes$formula <- paste0(water_nodes$formula,
    ifelse(number == 0, "", paste0(element, ifelse(number == 1, "", number))))
}
water_plot <- ggplot(water_nodes, aes(x, pair)) +
  geom_segment(data = tibble(pair = seq_len(nrow(water_pairs))),
    aes(x = 0, xend = 1, y = pair, yend = pair), inherit.aes = FALSE, linewidth = 0.6) +
  geom_point(aes(color = role), size = 4) +
  geom_text(aes(label = formula), nudge_y = 0.15, size = 4) +
  annotate("text", x = 0.5, y = seq_len(nrow(water_pairs)) - 0.1, label = "H2O", size = 4) +
  scale_color_manual(values = c("Mapped group" = "#0072B2", "Other molecular feature" = "#999999"),
    name = NULL) +
  scale_x_continuous(limits = c(-0.35, 1.35)) +
  scale_y_continuous(limits = c(0.6, nrow(water_pairs) + 0.45)) +
  theme_void(base_size = 12) + theme(legend.position = "bottom")
ggsave(file.path(figures_dir, "2016_core_h2o_formula_pairs.pdf"),
  water_plot, width = 7, height = 3.3, bg = "white")

# 9. Verify source preservation and retain numerical diagnostics ----------------
integrity <- tibble(path = substring(input_paths, nchar(here()) + 2L),
  md5_before = input_md5, md5_after = unname(tools::md5sum(input_paths))) %>%
  mutate(unchanged = md5_before == md5_after)
write_csv(integrity, file.path(results_dir, "input_integrity.csv"))
stopifnot(all(integrity$unchanged))
validation <- tibble(
  check = c("all_equal_feature_draws_completed", "paired_endpoints_count_twice",
    "observed_core_degree_finite", "null_draws_completed", "dispersion_probabilities_finite",
    "input_checksums_unchanged"),
  passed = c(all(draw_design$completed),
    sum(peak_events[, "all_connections"]) == 2 * sum(paired_occurrences),
    all(is.finite(feature_summary$mean_degree_per_detection)),
    all(null_runs$succeeded), all(is.finite(dispersion_test_table$p_value)),
    all(integrity$unchanged)))
write_csv(validation, file.path(results_dir, "numerical_validation.csv"))
stopifnot(all(validation$passed))
writeLines(trimws(capture.output(sessionInfo()), which = "right"),
  file.path(results_dir, "session_info.txt"))
message("Transformation context complete: ", nrow(tests), " conditional models; ",
  sum(core_lower & core_upper & paired_occurrences > 0),
  " observed within-core transformation pairs.")

# 10. Distinguish profile differences from within-site thinning variability ------
# E[||H||^2] = 1 for every Hellinger draw, so 1 - ||mean(H)||^2 is the
# exact mean squared deviation around each site's mean thinned profile.
context_sites <- read_csv(file.path(results_dir, "site_inclusion_audit.csv"),
  col_types = cols(site_code = col_character())) %>%
  mutate(network_group = factor(network_group, levels = group_levels))
mean_table <- read_csv(file.path(results_dir, "equal_feature_mean_hellinger.csv.gz"),
  col_types = cols(site_code = col_character()))
mean_profiles <- as.matrix(mean_table[match(context_sites$site_code, mean_table$site_code), -1])
sampling_variance <- 1 - rowSums(mean_profiles^2)
stopifnot(all(sampling_variance > -1e-12))
sampling_diagnostic <- context_sites %>%
  mutate(thinning_variance = pmax(0, sampling_variance),
    thinning_root_mean_squared_deviation = sqrt(thinning_variance))
write_csv(sampling_diagnostic, file.path(results_dir, "site_thinning_variability.csv"))
exact_selections <- read_csv(here("results", "fticr_2016", "matched_sediment_dispersion",
  "balanced_site_selection.csv"), col_types = cols(site_code = col_character()))
mean_dispersion_rows <- list()
mean_test_rows <- list()
mean_balanced_rows <- list()
for (pool in c("all", "matched")) {
  included <- rep(TRUE, nrow(context_sites))
  if (pool == "matched") included <- context_sites$matched_33
  selected_sites <- context_sites[included, ]
  distances <- as.matrix(dist(mean_profiles[included, ]))
  fit <- betadisper(as.dist(distances), selected_sites$network_group,
    type = "median", bias.adjust = TRUE)
  set.seed(permutation_seed + 101)
  test <- permutest(fit, permutations = n_permutations)
  means <- tapply(fit$distances, selected_sites$network_group, mean)
  mean_dispersion_rows[[pool]] <- selected_sites %>%
    mutate(pool, distance = fit$distances)
  mean_test_rows[[pool]] <- tibble(pool,
    headwater_mainstem_ratio = means["Headwater"] / means["Mainstem"],
    p_value = test$tab[1, "Pr(>F)"])
  if (pool != "matched") next
  for (run in sort(unique(exact_selections$run))) {
    current <- exact_selections %>% filter(.data$run == .env$run)
    i <- match(current$site_code, selected_sites$site_code)
    current_fit <- betadisper(as.dist(distances[i, i]), current$network_group,
      type = "median", bias.adjust = TRUE)
    current_means <- tapply(current_fit$distances, current$network_group, mean)
    mean_balanced_rows[[run]] <- tibble(run, view = "mean_profiles",
      headwater_mainstem_ratio = current_means["Headwater"] / current_means["Mainstem"])
  }
}
write_csv(bind_rows(mean_dispersion_rows),
  file.path(results_dir, "mean_profile_dispersion_by_site.csv"))
write_csv(bind_rows(mean_test_rows) %>% mutate(p_bh = p.adjust(p_value, "BH")),
  file.path(results_dir, "mean_profile_dispersion_tests.csv"))
mean_balanced <- bind_rows(mean_balanced_rows)
write_csv(mean_balanced, file.path(results_dir, "mean_profile_balanced_draws.csv"))
base_balanced <- read_csv(file.path(results_dir, "profile_dispersion_balanced_draws.csv"),
  show_col_types = FALSE)
comparison <- bind_rows(select(base_balanced, run, view, headwater_mainstem_ratio),
  mean_balanced) %>% mutate(view = factor(view,
    levels = c("complete", "equal_features", "mean_profiles"),
    labels = c("Complete profiles", "Mean thinned distances", "Mean thinned profiles")))
diagnostic_plot <- ggplot(comparison, aes(headwater_mainstem_ratio, view)) +
  geom_vline(xintercept = 1, linetype = 2, color = "#666666") +
  geom_boxplot(width = 0.5, fill = "#56B4E9", outlier.size = 0.7) +
  labs(x = "Headwater / mainstem transformation dispersion", y = NULL) + plot_theme
ggsave(file.path(figures_dir, "2016_transformation_thinning_diagnostic.pdf"),
  diagnostic_plot, width = 8, height = 3.6, bg = "white")
sampling_plot <- ggplot(sampling_diagnostic,
  aes(network_group, thinning_root_mean_squared_deviation, color = network_group)) +
  geom_boxplot(width = 0.55, outlier.shape = NA) +
  geom_point(position = position_jitter(width = 0.12, height = 0,
    seed = permutation_seed), alpha = 0.65, size = 2.4) +
  scale_color_manual(values = group_colors, guide = "none") +
  labs(x = NULL, y = "Within-site thinning variability\n(Hellinger RMS deviation)") + plot_theme
ggsave(file.path(figures_dir, "2016_transformation_sampling_variability.pdf"),
  sampling_plot, width = 5.8, height = 5.2, bg = "white")

# Check whether tighter chemical controls have enough background analogs.
coverage_core <- read_csv(here("results", "fticr_2016", "bipartite_networks",
  "stable_core_molecular_properties.csv"), show_col_types = FALSE) %>% filter(core == core_id)
coverage_peaks <- read_csv(here("results", "fticr_2016", "tables", "primary_peak_properties.csv"),
  show_col_types = FALSE)
coverage_candidates <- read_csv(file.path(results_dir, "core_null_candidate_pools.csv"),
  show_col_types = FALSE)
coverage_rows <- vector("list", nrow(coverage_core))
for (i in seq_len(nrow(coverage_core))) {
  target <- coverage_core[i, ]
  pool_ids <- coverage_candidates$candidate_feature[
    coverage_candidates$scheme == "prevalence_mass_elements" &
      coverage_candidates$target_feature == target$feature_id]
  pool <- coverage_peaks %>% filter(peak_id %in% pool_ids)
  ratio_match <- abs(pool$hydrogen_carbon_ratio - target$hydrogen_carbon_ratio) <= null_h_c_caliper &
    abs(pool$oxygen_carbon_ratio - target$oxygen_carbon_ratio) <= null_o_c_caliper
  strict_match <- ratio_match & pool$nitrogen_count == target$nitrogen_count &
    pool$candidate_count == 1
  coverage_rows[[i]] <- tibble(target_feature = target$feature_id,
    target_candidate_count = target$candidate_count,
    prevalence_mass_element_candidates = nrow(pool),
    additionally_ratio_matched = sum(ratio_match),
    additionally_exact_N_single_candidate = sum(strict_match))
}
write_csv(bind_rows(coverage_rows), file.path(results_dir, "core_null_pool_coverage.csv"))
diagnostic_validation <- tibble(
  check = c("thinning_variance_nonnegative", "mean_profile_dispersion_probabilities_finite"),
  passed = c(all(sampling_variance > -1e-12),
    all(is.finite(bind_rows(mean_test_rows)$p_value))))
existing_validation <- read_csv(file.path(results_dir, "numerical_validation.csv"),
  show_col_types = FALSE) %>% filter(!check %in% diagnostic_validation$check)
write_csv(bind_rows(existing_validation, diagnostic_validation),
  file.path(results_dir, "numerical_validation.csv"))
stopifnot(all(diagnostic_validation$passed))
