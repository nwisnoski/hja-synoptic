# Catchment-wide transformation summaries

The current interpretation centers on the bulk sediment transformation inventory.
Enzyme associations are retained as exploratory analyses and are excluded from
proposed main-text claims. River-position contrasts and annotations of the mapped
ASV–molecular group also remain exploratory; they do not establish functional
convergence or a metabolic guild. The selected manuscript figures are unchanged.

## Start with the descriptive summaries

[Supporting 12](supporting/12_molecular_transformations.R) constructs the
within-sample mass-difference profiles using the pinned
[Danczak reference](../reference/danczak_2020/README.md).
[Supporting 13](supporting/13_transformation_context.R) supplies formula checks;
[supporting 14](supporting/14_transformation_summary.R) assembles the ranked
catalogue and readable motif summary. Completed outputs are in
`results/fticr_2016/transformations/`.

- `transformation_label_catalogue.csv` describes every reference label by mean
  within-sample fraction, site coverage, distinct peak pairs, alternative
  assignments, and mass error. Its companion is
  [the rank distribution](../figures/supplement/transformations/2016_transformation_label_rank_distribution.pdf).
- `interpretable_motif_summary.csv` describes the declared subset of simple
  formula differences using readable compatible-change labels. Start with
  [the assignment summary](../figures/supplement/transformations/2016_transformation_assignment_summary.pdf)
  to distinguish compatible single-candidate formulas, compatible ambiguous
  formulas, and mass matches incompatible with the reported formulas.

The full catalogue contains 792 observed reference labels, including 299 present
in all 44 sediment profiles. The ten leading labels account for 8.4% of the mean
within-sample profile. The distribution therefore spans many labels; it is not
summarized by a handful of named reactions. Labels are reference assignments,
including alternative descriptions of similar mass differences, rather than a
count of distinct biological processes.

Within the curated motif subset, hydrogen, CH2, oxygen, water, acetyl-residue,
and carboxyl-group equivalents have the most formula-compatible distinct pairs.
All occur across the sampled catchment. Hexose-, glycine-, and valine-residue
equivalents are less frequent but also occur in every profile. Phosphate-group
and SO3 differences have few distinct compatible pairs, and the NH2 mass match
has no compatible assigned-formula pair. These findings describe the retained
molecular inventory; sparse matches do not diagnose nutrient limitation or the
absence of nutrient cycling.

Occurrence and assignment checks answer different questions. Site coverage and
pair counts describe how widespread and frequent a signature is. Formula
compatibility and candidate multiplicity describe its chemical assignment.
Neither supplies a probability that a reaction occurred. Single-candidate
formulas do not identify molecular structures, and many matches across sites
can involve the same peak pair.

## Candidate manuscript wording

“Across sediment samples, putative transformation matches encompassed a broad
range of mass differences. Within an interpretable subset, hydrogen-, oxygen-,
water-, and CH2-related differences were common, while hexose and amino acid
residue equivalents were less frequent but broadly distributed. These patterns
describe chemical relationships represented in streambed organic matter; they
do not identify realized reaction pathways, reaction rates, or taxon-specific
metabolism.”

Use this inventory as descriptive chemical context for the molecular composition
results. It does not add independent evidence that compositional convergence
in Figure 3 entails functional convergence or assign functioning to Figure 4's
association groups.

## Published treatment of detection and transformation counts

Source review on October 19, 2026 found no regression on log detected-feature
count and its square in the inspected Danczak transformation-ordination workflows.
The residual PCA in supporting 16 is an added conditional sensitivity analysis,
not an inherited PNNL correction or a validated estimate of technical bias.

| Source inspected | Treatment |
| --- | --- |
| [Danczak HJA analysis code](https://github.com/danczakre/HJA-FTICR-Ecology/blob/master/HJ_Andrews_Diversity_Analyses.R) | Divides each sample's transformation counts by their sum, then uses quantitative Jaccard dissimilarity and NMDS. Also analyzes observed molecular richness. |
| [PNNL transformation tutorial](https://github.com/danczakre/ICRTutorial/blob/master/Transformation_Analysis.R) | Retains raw count outputs and plots within-sample transformation proportions. |
| [Fudyma et al. (2021)](https://doi.org/10.3389/frwa.2020.574692) | Uses transformation percentages and CLR PCA; evaluates mixing expectations and relationships with total peak counts separately. |
| [Stegen et al. (2022), Methods](https://doi.org/10.5194/bg-19-3099-2022) | Standardizes organic carbon concentration before FT-ICR-MS, analyzes transformation counts, and uses relative transformation profiles with Bray–Curtis. |
| [Danczak et al. (2023), sections 2.4 and 3.2](https://doi.org/10.3389/frwa.2023.1087108) | Reports observed peak counts, transformation counts, and transformation counts divided by peak counts. |
| [Ryan et al. (2024), transformation methods](https://doi.org/10.1007/s10533-024-01169-5) | Uses counts divided by peak counts to describe connectivity while retaining molecular richness as a separate response. |

Conditioning is used elsewhere for specific questions: the
[Meta-Metabolome Raup–Crick code](https://github.com/danczakre/Meta-Metabolome_Ecology/blob/master/FTICR_RCBC_PresAbs.R)
keeps each sample's detected count in its null assemblages and samples molecular
identities according to occurrence frequency. That is a conditional null for
turnover, not residualization of the observed ordination.

For N detected peaks and T matched unordered pairs, N describes the observed
inventory, T/N is half the mean graph degree when all detected peaks are retained,
and T/[N(N-1)/2] is graph density. Neither normalization guarantees independence
from detection. Within-sample fractions T_j/T describe transformation composition;
the observed Hellinger PCA already uses these fractions. Residualization adds the
different question of what varies beyond the specified detection relationship.

A biological gradient can affect organic matter amount, molecular detection,
and transformation composition together. Detection count is therefore not known
to be a pure technical nuisance. Its strong association with summed intensity
also does not distinguish organic matter differences from extraction or
instrumental sensitivity. Published use of observed richness does not calibrate
our counts as true molecular richness. Interpret the observed profiles directly,
retain conditional fits as sensitivities, and consult the
[preparation methods](https://doi.org/10.5194/essd-11-1567-2019) before attributing
shared variation to technical bias. Those methods standardize sediment mass,
extraction volume, and acquisition settings without reporting equalization to
a common extract carbon concentration. Enzyme activity is normalized by AFDM.

## Retained exploratory analyses

These analyses remain reproducible, with their inputs, model definitions, and
interpretation limits in [METHODS.md](METHODS.md). Their results are not selected
as main-text evidence of microbial functioning.

| Script | Retained scope | Results and figure subfolder |
| --- | --- | --- |
| [Supporting 13](supporting/13_transformation_context.R) | River-position comparisons, feature-thinning diagnostics, and the mapped group's chemical neighborhood | `transformation_context/` |
| [Supporting 15](supporting/15_targeted_enzyme_transformations.R) | Six targeted enzyme–formula-difference comparisons and assignment sensitivities | `enzyme_transformations/` |
| [Supporting 16](supporting/16_transformation_gradients.R) | Observed Hellinger PCA, detection-conditioned PCA, loadings, and descriptive correlations | `transformation_gradients/` |
| [Supporting 17](supporting/17_transformation_detection_review.R) | Paired enzyme and river-position comparisons with and without detection conditioning | `transformation_detection_review/` |

Results are under `results/fticr_2016/`; figures are under `figures/supplement/`.
The enzyme relationships depend on model, denominator, assignment restrictions,
and cohort. They do not provide a compelling basis for attributing function to
these transformation profiles. Equal-feature thinning does not independently
establish functional convergence. The mapped group's two external H2O-compatible
pairs remain candidate chemical relationships rather than a functional annotation.

The observed PCA is a descriptive summary of within-sample transformation
fractions. Its leading axis covaries strongly with detection. The residual PCA
asks a separate conditional question: its percentages describe remaining
variance, not the original total. Detection conditioning is retained as a
sensitivity, not a default correction. Loading signs do not indicate reaction
direction. Enzyme-colored ordinations are exploratory visualizations.

## Supporting figure captions

- `2016_transformation_network_common_labels.pdf`: Site-weighted group means for
  the most common published labels. Text is the mean percentage of matched pairs;
  color is the mean deviation in site standard-deviation units. Fractions are
  descriptive and retain the reference database's labels and assignment order.
- `2016_transformation_network_pca.pdf`: Hellinger PCA of complete transformation
  profiles, colored by network position. Points are sediment profiles.
- `2016_core_transformation_matched_background.pdf`: Blue points show mapped-core
  motif fractions; open points and gray ranges show matched-background means and
  central 95% reference ranges. Ranges are not confidence intervals. Each incident
  connection contributes an endpoint to its focal feature.
- `2016_core_h2o_formula_pairs.pdf`: Undirected H2O-compatible formula differences.
  Blue features belong to the mapped group; gray features are other detected
  molecules. Edges indicate mass and formula compatibility, not reaction direction.
- The two `2016_transformation_dispersion_*.pdf` panels show matched-site distances
  to group spatial medians. `2016_transformation_thinning_diagnostic.pdf` compares
  the three profile representations using identical segment-balanced selections;
  these draw distributions are descriptive. `2016_transformation_sampling_variability.pdf`
  shows within-site RMS deviations across the feature-thinning draws.
